"""
Scripts for the Disaster Relief Management System
"""

