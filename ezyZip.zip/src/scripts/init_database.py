#!/usr/bin/env python3
"""
Database initialization script for the Disaster Relief Management System
"""

import sys
import os

# Add the parent directory to the path so we can import the modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from disaster_relief.core.database import DatabaseManager

def initialize_database():
    """Initialize the database with default data"""
    print("Initializing Disaster Relief Management System Database...")
    print("=" * 60)
    
    try:
        # Initialize database
        db = DatabaseManager()
        print("[OK] Database initialized successfully")
        
        # Add some sample inventory items
        print("\nAdding sample inventory items...")
        
        sample_items = [
            ("Water Bottles", "hydration", 1000, "pieces", "Warehouse A", "2024-12-31"),
            ("Medical Kits", "medical", 50, "kits", "Warehouse B", "2024-06-30"),
            ("Blankets", "shelter", 200, "pieces", "Warehouse A", None),
            ("Food Rations", "nutrition", 500, "meals", "Warehouse C", "2024-08-15"),
            ("First Aid Supplies", "medical", 100, "kits", "Warehouse B", "2024-05-20"),
            ("Emergency Shelter Tents", "shelter", 25, "units", "Warehouse A", None),
            ("Flashlights", "equipment", 150, "pieces", "Warehouse C", None),
            ("Batteries", "equipment", 300, "packs", "Warehouse C", "2024-10-30")
        ]
        
        for item_name, category, quantity, unit, location, expiry_date in sample_items:
            success = db.add_inventory_item(item_name, category, quantity, unit, location, expiry_date)
            if success:
                print(f"[OK] Added {item_name}")
            else:
                print(f"[ERROR] Failed to add {item_name}")
        
        print("\n" + "=" * 60)
        print("Database initialization completed successfully!")
        print("\nDefault admin account created:")
        print("  Email: admin@disaster-relief.com")
        print("  Password: admin123")
        print("\nYou can now run the application with: python -m disaster_relief_system")
        
    except Exception as e:
        print(f"[ERROR] Database initialization failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    initialize_database()

