#!/usr/bin/env python3
"""
Test suite for the Disaster Relief Management System
"""

import sys
import os

# Add the parent directory to the path so we can import the modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from disaster_relief.core.database import DatabaseManager
from disaster_relief.core.auth import AuthenticationManager

def test_database_creation():
    """Test database creation and schema"""
    print("Testing database creation...")
    
    try:
        # Create database
        db = DatabaseManager()
        print("[OK] Database created successfully")
        
        # Verify database file exists
        if os.path.exists(db.db_path):
            print("[OK] Database file exists")
        else:
            print("[ERROR] Database file missing")
            return False
        
        return True
    except Exception as e:
        print(f"[ERROR] Database creation failed: {e}")
        return False

def test_user_operations():
    """Test user creation and authentication"""
    print("Testing user operations...")
    
    try:
        db = DatabaseManager()
        auth = AuthenticationManager()
        
        # Test admin authentication
        admin = auth.login("admin@disaster-relief.com", "admin123")
        if admin:
            print("[OK] Admin authentication successful")
        else:
            print("[ERROR] Admin authentication failed")
            return False
        
        return True
    except Exception as e:
        print(f"[ERROR] User operations failed: {e}")
        return False

def test_inventory_operations():
    """Test inventory operations"""
    print("Testing inventory operations...")
    
    try:
        db = DatabaseManager()
        
        # Get inventory
        inventory = db.get_inventory()
        if inventory is not None:
            print(f"[OK] Retrieved {len(inventory)} inventory items")
        else:
            print("[ERROR] Failed to retrieve inventory")
            return False
        
        return True
    except Exception as e:
        print(f"[ERROR] Inventory operations failed: {e}")
        return False

def test_emergency_requests():
    """Test emergency request operations"""
    print("Testing emergency request operations...")
    
    try:
        db = DatabaseManager()
        
        # Get emergency requests
        requests = db.get_emergency_requests()
        if requests is not None:
            print(f"[OK] Retrieved {len(requests)} emergency requests")
        else:
            print("[ERROR] Failed to retrieve emergency requests")
            return False
        
        return True
    except Exception as e:
        print(f"[ERROR] Emergency request operations failed: {e}")
        return False

def main():
    """Run all tests"""
    print("Disaster Relief Management System - Test Suite")
    print("=" * 50)
    
    tests = [
        ("Database Creation", test_database_creation),
        ("User Operations", test_user_operations),
        ("Inventory Operations", test_inventory_operations),
        ("Emergency Requests", test_emergency_requests)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        try:
            if test_func():
                print(f"[PASS] {test_name}")
                passed += 1
            else:
                print(f"[FAIL] {test_name}")
                failed += 1
        except Exception as e:
            print(f"[ERROR] {test_name} failed with error: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("[SUCCESS] All tests passed!")
        return True
    else:
        print("[WARNING] Some tests failed")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)