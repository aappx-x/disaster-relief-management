#!/usr/bin/env python3
"""
Database initialization script for the Disaster Relief Management System (GUI version)
"""

import sys
import os
import tkinter as tk
from tkinter import messagebox, ttk
import threading

# Add the parent directory to the path so we can import the modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from disaster_relief_system.core.database import DatabaseManager

class DatabaseInitGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Database Initialization")
        self.root.geometry("500x400")
        self.root.configure(bg='#f0f0f0')
        
        # Center the window
        self.center_window()
        self.setup_ui()
    
    def center_window(self):
        """Center the window on the screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_ui(self):
        """Setup the user interface"""
        # Header
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Database Initialization", 
                              font=('Arial', 20, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(self.root, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=30)
        
        # Info frame
        info_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        info_frame.pack(expand=True, fill='both')
        
        # Description
        desc_label = tk.Label(info_frame, text="Initialize the Disaster Relief Management System Database", 
                             font=('Arial', 14, 'bold'), fg='#2c3e50', bg='white')
        desc_label.pack(pady=20)
        
        # Features list
        features_frame = tk.Frame(info_frame, bg='white')
        features_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        features = [
            "✓ Create database tables",
            "✓ Add sample inventory items",
            "✓ Create default admin account",
            "✓ Set up user authentication",
            "✓ Initialize system data"
        ]
        
        for feature in features:
            tk.Label(features_frame, text=feature, font=('Arial', 12), 
                    fg='#27ae60', bg='white').pack(anchor='w', pady=5)
        
        # Progress bar
        self.progress_var = tk.StringVar(value="Ready to initialize...")
        progress_label = tk.Label(features_frame, textvariable=self.progress_var, 
                                 font=('Arial', 10), fg='#7f8c8d', bg='white')
        progress_label.pack(pady=20)
        
        self.progress_bar = ttk.Progressbar(features_frame, mode='indeterminate')
        self.progress_bar.pack(fill='x', pady=(0, 20))
        
        # Buttons
        button_frame = tk.Frame(info_frame, bg='white')
        button_frame.pack(pady=20)
        
        self.init_btn = tk.Button(button_frame, text="Initialize Database", 
                                 command=self.start_initialization,
                                 font=('Arial', 12, 'bold'), bg='#3498db', fg='white',
                                 relief='flat', bd=0, padx=30, pady=10)
        self.init_btn.pack(side='left', padx=10)
        
        self.close_btn = tk.Button(button_frame, text="Close", 
                                  command=self.root.destroy,
                                  font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                                  relief='flat', bd=0, padx=30, pady=10)
        self.close_btn.pack(side='left', padx=10)
        
        # Default credentials info
        creds_frame = tk.Frame(info_frame, bg='#ecf0f1', relief='solid', bd=1)
        creds_frame.pack(fill='x', padx=20, pady=20)
        
        tk.Label(creds_frame, text="Default Admin Credentials:", font=('Arial', 10, 'bold'), 
                fg='#2c3e50', bg='#ecf0f1').pack(pady=5)
        tk.Label(creds_frame, text="Email: admin@disaster-relief.com", font=('Arial', 10), 
                fg='#7f8c8d', bg='#ecf0f1').pack()
        tk.Label(creds_frame, text="Password: admin123", font=('Arial', 10), 
                fg='#7f8c8d', bg='#ecf0f1').pack(pady=(0, 5))
    
    def start_initialization(self):
        """Start database initialization in a separate thread"""
        self.init_btn.config(state='disabled')
        self.progress_bar.start()
        self.progress_var.set("Initializing database...")
        
        # Run initialization in a separate thread
        thread = threading.Thread(target=self.initialize_database)
        thread.daemon = True
        thread.start()
    
    def initialize_database(self):
        """Initialize the database"""
        try:
            # Initialize database
            db = DatabaseManager()
            self.root.after(0, lambda: self.progress_var.set("Database initialized successfully"))
            
            # Add sample inventory items
            sample_items = [
                ("Water Bottles", "hydration", 1000, "pieces", "Warehouse A", "2024-12-31"),
                ("Medical Kits", "medical", 50, "kits", "Warehouse B", "2024-06-30"),
                ("Blankets", "shelter", 200, "pieces", "Warehouse A", None),
                ("Food Rations", "nutrition", 500, "meals", "Warehouse C", "2024-08-15"),
                ("First Aid Supplies", "medical", 100, "kits", "Warehouse B", "2024-05-20"),
                ("Emergency Shelter Tents", "shelter", 25, "units", "Warehouse A", None),
                ("Flashlights", "equipment", 150, "pieces", "Warehouse C", None),
                ("Batteries", "equipment", 300, "packs", "Warehouse C", "2024-10-30")
            ]
            
            for i, (item_name, category, quantity, unit, location, expiry_date) in enumerate(sample_items):
                self.root.after(0, lambda i=i, total=len(sample_items): 
                              self.progress_var.set(f"Adding inventory items... ({i+1}/{total})"))
                db.add_inventory_item(item_name, category, quantity, unit, location, expiry_date)
            
            # Complete
            self.root.after(0, self.initialization_complete)
            
        except Exception as e:
            self.root.after(0, lambda: self.initialization_error(str(e)))
    
    def initialization_complete(self):
        """Handle successful initialization"""
        self.progress_bar.stop()
        self.progress_var.set("Database initialization completed successfully!")
        self.init_btn.config(state='normal', text='Reinitialize Database')
        
        messagebox.showinfo("Success", 
                           "Database initialized successfully!\n\n"
                           "Default admin account created:\n"
                           "Email: admin@disaster-relief.com\n"
                           "Password: admin123\n\n"
                           "You can now run the application.")
    
    def initialization_error(self, error_msg):
        """Handle initialization error"""
        self.progress_bar.stop()
        self.progress_var.set("Initialization failed!")
        self.init_btn.config(state='normal')
        
        messagebox.showerror("Error", f"Database initialization failed:\n{error_msg}")
    
    def run(self):
        """Run the GUI"""
        self.root.mainloop()

def main():
    """Main entry point"""
    try:
        app = DatabaseInitGUI()
        app.run()
    except Exception as e:
        print(f"Error running database initialization GUI: {e}")

if __name__ == "__main__":
    main()

