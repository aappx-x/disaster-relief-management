#!/usr/bin/env python3
"""
Quick start script for the Disaster Relief Management System
"""

import sys
import os

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 6):
        print("Error: Python 3.6 or higher is required.")
        print(f"Current version: {sys.version}")
        sys.exit(1)

def check_required_files():
    """Check if all required files are present"""
    required_files = [
        'disaster_relief/__init__.py',
        'disaster_relief/main.py',
        'disaster_relief/core/database.py',
        'disaster_relief/core/auth.py',
        'disaster_relief/cli/interfaces.py'
    ]
    missing_files = []
    
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print("Error: Missing required files:")
        for file in missing_files:
            print(f"  - {file}")
        sys.exit(1)

def main():
    """Main entry point with checks"""
    print("Disaster Relief Management System")
    print("=" * 40)
    
    # Check Python version
    check_python_version()
    print("✓ Python version check passed")
    
    # Check required files
    check_required_files()
    print("✓ Required files check passed")
    
    print("\nStarting application...")
    print("=" * 40)
    
    # Import and run the main application
    try:
        from disaster_relief.main import main as app_main
        app_main()
    except ImportError as e:
        print(f"Error importing application: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error running application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

