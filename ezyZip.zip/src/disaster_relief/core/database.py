import sqlite3
import hashlib
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import json
import os

class DatabaseManager:
    def __init__(self, db_path: str = None):
        if db_path is None:
            # Use project root data directory for database
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
            data_dir = os.path.join(project_root, 'data')
            os.makedirs(data_dir, exist_ok=True)
            self.db_path = os.path.join(data_dir, "disaster_relief.db")
        else:
            self.db_path = db_path
        
        self.init_database()
    
    def init_database(self):
        """Initialize the database with all required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table (for disaster victims)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                emergency_type TEXT NOT NULL,
                location TEXT NOT NULL,
                contact_info TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Volunteers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS volunteers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                skills TEXT,
                availability TEXT,
                location TEXT NOT NULL,
                contact_info TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Admins table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'admin',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Emergency requests table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS emergency_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                request_type TEXT NOT NULL,
                description TEXT NOT NULL,
                priority TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'pending',
                location TEXT NOT NULL,
                contact_info TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                assigned_volunteer_id INTEGER,
                admin_notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (assigned_volunteer_id) REFERENCES volunteers (id)
            )
        ''')
        
        
        # Inventory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_name TEXT NOT NULL,
                category TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit TEXT NOT NULL,
                location TEXT NOT NULL,
                expiry_date DATE,
                status TEXT DEFAULT 'available',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Supply requests table (linking emergency requests to inventory)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS supply_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                emergency_request_id INTEGER NOT NULL,
                inventory_id INTEGER NOT NULL,
                requested_quantity INTEGER NOT NULL,
                allocated_quantity INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (emergency_request_id) REFERENCES emergency_requests (id),
                FOREIGN KEY (inventory_id) REFERENCES inventory (id)
            )
        ''')
        
        # Create default admin if not exists
        cursor.execute('SELECT COUNT(*) FROM admins')
        if cursor.fetchone()[0] == 0:
            admin_password = self.hash_password('admin123')
            cursor.execute('''
                INSERT INTO admins (username, email, password_hash, role)
                VALUES (?, ?, ?, ?)
            ''', ('admin', 'admin@disaster-relief.com', admin_password, 'admin'))
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return self.hash_password(password) == hashed
    
    def create_user(self, username: str, email: str, password: str, 
                   emergency_type: str, location: str, contact_info: str) -> bool:
        """Create a new user account"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, emergency_type, location, contact_info)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (username, email, password_hash, emergency_type, location, contact_info))
            
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    def create_volunteer(self, username: str, email: str, password: str,
                        skills: str, availability: str, location: str, contact_info: str) -> bool:
        """Create a new volunteer account"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO volunteers (username, email, password_hash, skills, availability, location, contact_info)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (username, email, password_hash, skills, availability, location, contact_info))
            
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    def authenticate_user(self, email: str, password: str) -> Optional[Dict]:
        """Authenticate user and return user info"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check users table
        cursor.execute('SELECT id, username, email, emergency_type, location, contact_info, password_hash FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        
        if user and self.verify_password(password, user[6]):
            conn.close()
            return {
                'id': user[0],
                'username': user[1],
                'email': user[2],
                'emergency_type': user[3],
                'location': user[4],
                'contact_info': user[5],
                'role': 'user'
            }
        
        # Check volunteers table
        cursor.execute('SELECT id, username, email, skills, availability, location, contact_info, password_hash FROM volunteers WHERE email = ?', (email,))
        volunteer = cursor.fetchone()
        
        if volunteer and self.verify_password(password, volunteer[7]):
            conn.close()
            return {
                'id': volunteer[0],
                'username': volunteer[1],
                'email': volunteer[2],
                'skills': volunteer[3],
                'availability': volunteer[4],
                'location': volunteer[5],
                'contact_info': volunteer[6],
                'role': 'volunteer'
            }
        
        # Check admins table
        cursor.execute('SELECT id, username, email, role, password_hash FROM admins WHERE email = ?', (email,))
        admin = cursor.fetchone()
        
        if admin and self.verify_password(password, admin[4]):
            conn.close()
            return {
                'id': admin[0],
                'username': admin[1],
                'email': admin[2],
                'role': admin[3]
            }
        
        conn.close()
        return None
    
    def create_emergency_request(self, user_id: int, request_type: str, description: str,
                               priority: str, location: str, contact_info: str) -> int:
        """Create a new emergency request"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO emergency_requests (user_id, request_type, description, priority, location, contact_info)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, request_type, description, priority, location, contact_info))
        
        request_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return request_id
    
    def get_emergency_requests(self, status: str = None) -> List[Dict]:
        """Get emergency requests, optionally filtered by status (Admin only - sees all requests)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if status:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                WHERE er.status = ?
                ORDER BY er.created_at DESC
            ''', (status,))
        else:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                ORDER BY er.created_at DESC
            ''')
        
        requests = []
        for row in cursor.fetchall():
            requests.append({
                'id': row[0],
                'request_type': row[1],
                'description': row[2],
                'priority': row[3],
                'status': row[4],
                'location': row[5],
                'contact_info': row[6],
                'created_at': row[7],
                'username': row[8]
            })
        
        conn.close()
        return requests
    
    def get_user_emergency_requests(self, user_id: int, status: str = None) -> List[Dict]:
        """Get emergency requests for a specific user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if status:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                WHERE er.user_id = ? AND er.status = ?
                ORDER BY er.created_at DESC
            ''', (user_id, status))
        else:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                WHERE er.user_id = ?
                ORDER BY er.created_at DESC
            ''', (user_id,))
        
        requests = []
        for row in cursor.fetchall():
            requests.append({
                'id': row[0],
                'request_type': row[1],
                'description': row[2],
                'priority': row[3],
                'status': row[4],
                'location': row[5],
                'contact_info': row[6],
                'created_at': row[7],
                'username': row[8]
            })
        
        conn.close()
        return requests
    
    def get_available_emergency_requests(self, status: str = None) -> List[Dict]:
        """Get available emergency requests for volunteers (approved requests that need help)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Volunteers can see approved and in_progress requests
        if status:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                WHERE er.status = ? AND er.status IN ('approved', 'in_progress')
                ORDER BY er.created_at DESC
            ''', (status,))
        else:
            cursor.execute('''
                SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                       er.location, er.contact_info, er.created_at, u.username
                FROM emergency_requests er
                JOIN users u ON er.user_id = u.id
                WHERE er.status IN ('approved', 'in_progress')
                ORDER BY er.created_at DESC
            ''')
        
        requests = []
        for row in cursor.fetchall():
            requests.append({
                'id': row[0],
                'request_type': row[1],
                'description': row[2],
                'priority': row[3],
                'status': row[4],
                'location': row[5],
                'contact_info': row[6],
                'created_at': row[7],
                'username': row[8]
            })
        
        conn.close()
        return requests
    
    def update_request_status(self, request_id: int, status: str, admin_notes: str = None, assigned_volunteer_id: int = None) -> bool:
        """Update emergency request status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE emergency_requests 
            SET status = ?, admin_notes = ?, assigned_volunteer_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (status, admin_notes, assigned_volunteer_id, request_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success
    
    def get_inventory(self) -> List[Dict]:
        """Get all inventory items"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, item_name, category, quantity, unit, location, expiry_date, status
            FROM inventory
            ORDER BY item_name
        ''')
        
        inventory = []
        for row in cursor.fetchall():
            inventory.append({
                'id': row[0],
                'item_name': row[1],
                'category': row[2],
                'quantity': row[3],
                'unit': row[4],
                'location': row[5],
                'expiry_date': row[6],
                'status': row[7]
            })
        
        conn.close()
        return inventory
    
    def add_inventory_item(self, item_name: str, category: str, quantity: int, 
                          unit: str, location: str, expiry_date: str = None) -> bool:
        """Add new inventory item"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO inventory (item_name, category, quantity, unit, location, expiry_date)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (item_name, category, quantity, unit, location, expiry_date))
            
            conn.commit()
            conn.close()
            return True
        except Exception:
            return False
    
    def update_inventory_quantity(self, item_id: int, new_quantity: int) -> bool:
        """Update inventory quantity"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE inventory 
            SET quantity = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (new_quantity, item_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success
    
    def get_volunteers(self) -> List[Dict]:
        """Get all volunteers"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, email, skills, availability, location, contact_info, status
            FROM volunteers
            ORDER BY username
        ''')
        
        volunteers = []
        for row in cursor.fetchall():
            volunteers.append({
                'id': row[0],
                'username': row[1],
                'email': row[2],
                'skills': row[3],
                'availability': row[4],
                'location': row[5],
                'contact_info': row[6],
                'status': row[7]
            })
        
        conn.close()
        return volunteers
    
    def assign_request_to_volunteer(self, request_id: int, volunteer_id: int, admin_notes: str = None) -> bool:
        """Assign a request to a specific volunteer"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE emergency_requests 
            SET assigned_volunteer_id = ?, admin_notes = ?, status = 'assigned', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (volunteer_id, admin_notes, request_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success
    
    def get_volunteer_assignments(self, volunteer_id: int) -> List[Dict]:
        """Get all assignments for a specific volunteer"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                   er.location, er.contact_info, er.created_at, er.admin_notes, u.username
            FROM emergency_requests er
            JOIN users u ON er.user_id = u.id
            WHERE er.assigned_volunteer_id = ?
            ORDER BY er.created_at DESC
        ''', (volunteer_id,))
        
        assignments = []
        for row in cursor.fetchall():
            assignments.append({
                'id': row[0],
                'request_type': row[1],
                'description': row[2],
                'priority': row[3],
                'status': row[4],
                'location': row[5],
                'contact_info': row[6],
                'created_at': row[7],
                'admin_notes': row[8],
                'username': row[9]
            })
        
        conn.close()
        return assignments
    
    def volunteer_respond_to_assignment(self, request_id: int, volunteer_id: int, response: str) -> bool:
        """Handle volunteer's response to assignment (accept/reject)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if response.lower() == 'accept':
            new_status = 'accepted'
        elif response.lower() == 'reject':
            new_status = 'pending'
            # Clear the assignment when rejected
            cursor.execute('''
                UPDATE emergency_requests 
                SET status = ?, assigned_volunteer_id = NULL, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND assigned_volunteer_id = ?
            ''', (new_status, request_id, volunteer_id))
        else:
            conn.close()
            return False
        
        if response.lower() == 'accept':
            cursor.execute('''
                UPDATE emergency_requests 
                SET status = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND assigned_volunteer_id = ?
            ''', (new_status, request_id, volunteer_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success
    
    def get_requests_by_status(self, status: str) -> List[Dict]:
        """Get requests filtered by specific status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT er.id, er.request_type, er.description, er.priority, er.status, 
                   er.location, er.contact_info, er.created_at, u.username, er.assigned_volunteer_id
            FROM emergency_requests er
            JOIN users u ON er.user_id = u.id
            WHERE er.status = ?
            ORDER BY er.created_at DESC
        ''', (status,))
        
        requests = []
        for row in cursor.fetchall():
            requests.append({
                'id': row[0],
                'request_type': row[1],
                'description': row[2],
                'priority': row[3],
                'status': row[4],
                'location': row[5],
                'contact_info': row[6],
                'created_at': row[7],
                'username': row[8],
                'assigned_volunteer_id': row[9]
            })
        
        conn.close()
        return requests
    

