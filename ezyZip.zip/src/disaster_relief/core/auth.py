from .database import DatabaseManager
from typing import Optional, Dict

class AuthenticationManager:
    def __init__(self):
        self.db = DatabaseManager()
        self.current_user = None
    
    def login(self, email: str, password: str) -> Optional[Dict]:
        """Authenticate user and set current user"""
        user = self.db.authenticate_user(email, password)
        if user:
            self.current_user = user
        return user
    
    def logout(self):
        """Logout current user"""
        self.current_user = None
    
    def is_authenticated(self) -> bool:
        """Check if user is authenticated"""
        return self.current_user is not None
    
    def get_current_user(self) -> Optional[Dict]:
        """Get current authenticated user"""
        return self.current_user
    
    def get_user_role(self) -> Optional[str]:
        """Get current user's role"""
        if self.current_user:
            return self.current_user.get('role')
        return None
    
    def register_user(self, username: str, email: str, password: str, 
                     emergency_type: str, location: str, contact_info: str) -> bool:
        """Register a new user"""
        return self.db.create_user(username, email, password, emergency_type, location, contact_info)
    
    def register_volunteer(self, username: str, email: str, password: str,
                          skills: str, availability: str, location: str, contact_info: str) -> bool:
        """Register a new volunteer"""
        return self.db.create_volunteer(username, email, password, skills, availability, location, contact_info)

