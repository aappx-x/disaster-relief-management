"""
Disaster Relief Supply Management System
A Python application for managing disaster relief supplies and user registrations.
"""

__version__ = "1.0.0"
__author__ = "Disaster Relief Team"
__description__ = "A comprehensive disaster relief management system"

