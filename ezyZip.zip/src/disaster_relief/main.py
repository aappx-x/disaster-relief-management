#!/usr/bin/env python3
"""
Disaster Relief Supply Management System
A Python application for managing disaster relief supplies and user registrations.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from disaster_relief_system.ui.interfaces import LoginInterface, UserDashboard, VolunteerDashboard, AdminDashboard

class DisasterReliefApp:
    def __init__(self):
        self.login_interface = LoginInterface()
    
    def run(self):
        """Main application loop"""
        while True:
            self.show_main_menu()
    
    def show_main_menu(self):
        """Display main menu"""
        self.login_interface.clear_screen()
        self.login_interface.display_header("Disaster Relief Management System")
        
        options = [
            "Login",
            "Register as User",
            "Register as Volunteer",
            "Exit"
        ]
        
        self.login_interface.display_menu(options, "Main Menu")
        choice = self.login_interface.get_user_choice(len(options))
        
        if choice == 1:
            self.handle_login()
        elif choice == 2:
            self.handle_user_registration()
        elif choice == 3:
            self.handle_volunteer_registration()
        elif choice == 4:
            self.exit_application()
    
    def handle_login(self):
        """Handle user login"""
        user = self.login_interface.show_login_form()
        if user:
            self.route_to_dashboard(user)
    
    def handle_user_registration(self):
        """Handle user registration"""
        success = self.login_interface.show_registration_form("user")
        if success:
            # After successful registration, ask if user wants to login
            login_choice = self.login_interface.get_user_input("Would you like to login now? (y/n)")
            if login_choice.lower() == 'y':
                self.handle_login()
    
    def handle_volunteer_registration(self):
        """Handle volunteer registration"""
        success = self.login_interface.show_registration_form("volunteer")
        if success:
            # After successful registration, ask if user wants to login
            login_choice = self.login_interface.get_user_input("Would you like to login now? (y/n)")
            if login_choice.lower() == 'y':
                self.handle_login()
    
    def route_to_dashboard(self, user):
        """Route user to appropriate dashboard based on role"""
        role = user.get('role')
        
        if role == 'user':
            dashboard = UserDashboard(user)
            dashboard.show_dashboard()
        elif role == 'volunteer':
            dashboard = VolunteerDashboard(user)
            dashboard.show_dashboard()
        elif role == 'admin':
            dashboard = AdminDashboard(user)
            dashboard.show_dashboard()
        else:
            self.login_interface.display_error_message("Unknown user role")
    
    def exit_application(self):
        """Exit the application"""
        self.login_interface.clear_screen()
        print("Thank you for using the Disaster Relief Management System!")
        print("Stay safe!")
        sys.exit(0)

def main():
    """Main entry point"""
    try:
        app = DisasterReliefApp()
        app.run()
    except KeyboardInterrupt:
        print("\n\nApplication interrupted by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
