import os
import sys
from typing import Optional, Dict, List
from ..core.auth import AuthenticationManager
from ..core.database import DatabaseManager

class UserInterface:
    def __init__(self):
        self.auth = AuthenticationManager()
        self.db = DatabaseManager()
    
    def clear_screen(self):
        """Clear the console screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def display_header(self, title: str):
        """Display a formatted header"""
        print("=" * 60)
        print(f"  {title}")
        print("=" * 60)
    
    def display_menu(self, options: List[str], title: str = "Menu"):
        """Display a menu with options"""
        self.display_header(title)
        for i, option in enumerate(options, 1):
            print(f"{i}. {option}")
        print("=" * 60)
    
    def get_user_input(self, prompt: str) -> str:
        """Get user input with prompt"""
        return input(f"{prompt}: ").strip()
    
    def get_user_choice(self, max_choice: int) -> int:
        """Get user menu choice"""
        while True:
            try:
                choice = int(input("Enter your choice: "))
                if 1 <= choice <= max_choice:
                    return choice
                else:
                    print(f"Please enter a number between 1 and {max_choice}")
            except ValueError:
                print("Please enter a valid number")
    
    def display_success_message(self, message: str):
        """Display success message"""
        print(f"\n✓ {message}")
        input("Press Enter to continue...")
    
    def display_error_message(self, message: str):
        """Display error message"""
        print(f"\n✗ {message}")
        input("Press Enter to continue...")

class LoginInterface(UserInterface):
    def __init__(self):
        super().__init__()
    
    def show_login_form(self) -> Optional[Dict]:
        """Display login form and return authenticated user"""
        self.clear_screen()
        self.display_header("Disaster Relief Management System - Login")
        
        email = self.get_user_input("Email")
        password = self.get_user_input("Password")
        
        if not email or not password:
            self.display_error_message("Email and password are required")
            return None
        
        user = self.auth.login(email, password)
        if user:
            self.display_success_message(f"Welcome, {user['username']}!")
            return user
        else:
            self.display_error_message("Invalid email or password")
            return None
    
    def show_registration_form(self, user_type: str = "user") -> bool:
        """Display registration form"""
        self.clear_screen()
        self.display_header(f"Register as {user_type.title()}")
        
        username = self.get_user_input("Username")
        email = self.get_user_input("Email")
        password = self.get_user_input("Password")
        
        if not username or not email or not password:
            self.display_error_message("All fields are required")
            return False
        
        if user_type == "user":
            emergency_type = self.get_user_input("Emergency Type (e.g., flood, earthquake)")
            location = self.get_user_input("Location")
            contact_info = self.get_user_input("Contact Information")
            
            if not emergency_type or not location or not contact_info:
                self.display_error_message("All fields are required")
                return False
            
            success = self.auth.register_user(username, email, password, emergency_type, location, contact_info)
        else:  # volunteer
            skills = self.get_user_input("Skills (comma-separated)")
            availability = self.get_user_input("Availability (e.g., weekdays, weekends)")
            location = self.get_user_input("Location")
            contact_info = self.get_user_input("Contact Information")
            
            if not skills or not availability or not location or not contact_info:
                self.display_error_message("All fields are required")
                return False
            
            success = self.auth.register_volunteer(username, email, password, skills, availability, location, contact_info)
        
        if success:
            self.display_success_message(f"{user_type.title()} registration successful!")
            return True
        else:
            self.display_error_message("Registration failed. Username or email may already exist.")
            return False

class UserDashboard(UserInterface):
    def __init__(self, user: Dict):
        super().__init__()
        self.user = user
    
    def show_dashboard(self):
        """Show user dashboard"""
        while True:
            self.clear_screen()
            self.display_header(f"User Dashboard - Welcome {self.user['username']}")
            
            options = [
                "Submit Emergency Request",
                "View My Requests",
                "Update Profile",
                "Logout"
            ]
            
            self.display_menu(options, "User Options")
            choice = self.get_user_choice(len(options))
            
            if choice == 1:
                self.submit_emergency_request()
            elif choice == 2:
                self.view_my_requests()
            elif choice == 3:
                self.update_profile()
            elif choice == 4:
                self.auth.logout()
                break
    
    def submit_emergency_request(self):
        """Submit emergency request"""
        self.clear_screen()
        self.display_header("Submit Emergency Request")
        
        request_type = self.get_user_input("Request Type (e.g., food, water, medical, shelter)")
        description = self.get_user_input("Description")
        priority = self.get_user_input("Priority (low, medium, high)")
        location = self.get_user_input("Location")
        contact_info = self.get_user_input("Contact Information")
        
        if not all([request_type, description, priority, location, contact_info]):
            self.display_error_message("All fields are required")
            return
        
        request_id = self.db.create_emergency_request(
            self.user['id'], request_type, description, priority, location, contact_info
        )
        
        if request_id:
            self.display_success_message(f"Emergency request submitted successfully! Request ID: {request_id}")
        else:
            self.display_error_message("Failed to submit emergency request")
    
    def view_my_requests(self):
        """View user's emergency requests"""
        self.clear_screen()
        self.display_header("My Emergency Requests")
        
        requests = self.db.get_emergency_requests()
        user_requests = [req for req in requests if req['username'] == self.user['username']]
        
        if not user_requests:
            print("No emergency requests found.")
        else:
            for req in user_requests:
                print(f"\nRequest ID: {req['id']}")
                print(f"Type: {req['request_type']}")
                print(f"Description: {req['description']}")
                print(f"Priority: {req['priority']}")
                print(f"Status: {req['status']}")
                print(f"Location: {req['location']}")
                print(f"Created: {req['created_at']}")
                print("-" * 40)
        
        input("Press Enter to continue...")
    
    def update_profile(self):
        """Update user profile"""
        self.clear_screen()
        self.display_header("Update Profile")
        print("Profile update functionality would be implemented here.")
        input("Press Enter to continue...")

class VolunteerDashboard(UserInterface):
    def __init__(self, volunteer: Dict):
        super().__init__()
        self.volunteer = volunteer
    
    def show_dashboard(self):
        """Show volunteer dashboard"""
        while True:
            self.clear_screen()
            self.display_header(f"Volunteer Dashboard - Welcome {self.volunteer['username']}")
            
            options = [
                "View Available Requests",
                "View My Assignments",
                "Update Availability",
                "Logout"
            ]
            
            self.display_menu(options, "Volunteer Options")
            choice = self.get_user_choice(len(options))
            
            if choice == 1:
                self.view_available_requests()
            elif choice == 2:
                self.view_my_assignments()
            elif choice == 3:
                self.update_availability()
            elif choice == 4:
                self.auth.logout()
                break
    
    def view_available_requests(self):
        """View available emergency requests"""
        self.clear_screen()
        self.display_header("Available Emergency Requests")
        
        requests = self.db.get_emergency_requests('pending')
        
        if not requests:
            print("No pending emergency requests found.")
        else:
            for req in requests:
                print(f"\nRequest ID: {req['id']}")
                print(f"Type: {req['request_type']}")
                print(f"Description: {req['description']}")
                print(f"Priority: {req['priority']}")
                print(f"Location: {req['location']}")
                print(f"Contact: {req['contact_info']}")
                print(f"Created: {req['created_at']}")
                print("-" * 40)
        
        input("Press Enter to continue...")
    
    def view_my_assignments(self):
        """View volunteer's assignments"""
        self.clear_screen()
        self.display_header("My Assignments")
        
        # This would require additional database queries to get assignments
        print("Assignment viewing functionality would be implemented here.")
        input("Press Enter to continue...")
    
    def update_availability(self):
        """Update volunteer availability"""
        self.clear_screen()
        self.display_header("Update Availability")
        print("Availability update functionality would be implemented here.")
        input("Press Enter to continue...")

class AdminDashboard(UserInterface):
    def __init__(self, admin: Dict):
        super().__init__()
        self.admin = admin
    
    def show_dashboard(self):
        """Show admin dashboard"""
        while True:
            self.clear_screen()
            self.display_header(f"Admin Dashboard - Welcome {self.admin['username']}")
            
            options = [
                "View All Requests",
                "Manage Inventory",
                "Manage Volunteers",
                "Assign Volunteers",
                "Generate Reports",
                "Logout"
            ]
            
            self.display_menu(options, "Admin Options")
            choice = self.get_user_choice(len(options))
            
            if choice == 1:
                self.view_all_requests()
            elif choice == 2:
                self.manage_inventory()
            elif choice == 3:
                self.manage_volunteers()
            elif choice == 4:
                self.assign_volunteers()
            elif choice == 5:
                self.generate_reports()
            elif choice == 6:
                self.auth.logout()
                break
    
    def view_all_requests(self):
        """View all emergency requests"""
        self.clear_screen()
        self.display_header("All Emergency Requests")
        
        requests = self.db.get_emergency_requests()
        
        if not requests:
            print("No emergency requests found.")
        else:
            for req in requests:
                print(f"\nRequest ID: {req['id']}")
                print(f"User: {req['username']}")
                print(f"Type: {req['request_type']}")
                print(f"Description: {req['description']}")
                print(f"Priority: {req['priority']}")
                print(f"Status: {req['status']}")
                print(f"Location: {req['location']}")
                print(f"Contact: {req['contact_info']}")
                print(f"Created: {req['created_at']}")
                print("-" * 40)
        
        input("Press Enter to continue...")
    
    def manage_inventory(self):
        """Manage inventory"""
        self.clear_screen()
        self.display_header("Inventory Management")
        
        options = [
            "View Inventory",
            "Add New Item",
            "Update Item Quantity",
            "Back to Dashboard"
        ]
        
        self.display_menu(options, "Inventory Options")
        choice = self.get_user_choice(len(options))
        
        if choice == 1:
            self.view_inventory()
        elif choice == 2:
            self.add_inventory_item()
        elif choice == 3:
            self.update_inventory_quantity()
        elif choice == 4:
            return
    
    def view_inventory(self):
        """View current inventory"""
        self.clear_screen()
        self.display_header("Current Inventory")
        
        inventory = self.db.get_inventory()
        
        if not inventory:
            print("No inventory items found.")
        else:
            for item in inventory:
                print(f"\nID: {item['id']}")
                print(f"Item: {item['item_name']}")
                print(f"Category: {item['category']}")
                print(f"Quantity: {item['quantity']} {item['unit']}")
                print(f"Location: {item['location']}")
                print(f"Status: {item['status']}")
                if item['expiry_date']:
                    print(f"Expiry: {item['expiry_date']}")
                print("-" * 40)
        
        input("Press Enter to continue...")
    
    def add_inventory_item(self):
        """Add new inventory item"""
        self.clear_screen()
        self.display_header("Add New Inventory Item")
        
        item_name = self.get_user_input("Item Name")
        category = self.get_user_input("Category")
        quantity = self.get_user_input("Quantity")
        unit = self.get_user_input("Unit (e.g., pieces, kg, liters)")
        location = self.get_user_input("Storage Location")
        expiry_date = self.get_user_input("Expiry Date (YYYY-MM-DD, optional)")
        
        if not all([item_name, category, quantity, unit, location]):
            self.display_error_message("All required fields must be filled")
            return
        
        try:
            quantity = int(quantity)
        except ValueError:
            self.display_error_message("Quantity must be a number")
            return
        
        success = self.db.add_inventory_item(item_name, category, quantity, unit, location, expiry_date)
        
        if success:
            self.display_success_message("Inventory item added successfully!")
        else:
            self.display_error_message("Failed to add inventory item")
    
    def update_inventory_quantity(self):
        """Update inventory quantity"""
        self.clear_screen()
        self.display_header("Update Inventory Quantity")
        
        item_id = self.get_user_input("Item ID")
        new_quantity = self.get_user_input("New Quantity")
        
        try:
            item_id = int(item_id)
            new_quantity = int(new_quantity)
        except ValueError:
            self.display_error_message("Item ID and quantity must be numbers")
            return
        
        success = self.db.update_inventory_quantity(item_id, new_quantity)
        
        if success:
            self.display_success_message("Inventory quantity updated successfully!")
        else:
            self.display_error_message("Failed to update inventory quantity")
    
    def manage_volunteers(self):
        """Manage volunteers"""
        self.clear_screen()
        self.display_header("Volunteer Management")
        
        volunteers = self.db.get_volunteers()
        
        if not volunteers:
            print("No volunteers found.")
        else:
            for volunteer in volunteers:
                print(f"\nID: {volunteer['id']}")
                print(f"Username: {volunteer['username']}")
                print(f"Email: {volunteer['email']}")
                print(f"Skills: {volunteer['skills']}")
                print(f"Availability: {volunteer['availability']}")
                print(f"Location: {volunteer['location']}")
                print(f"Status: {volunteer['status']}")
                print("-" * 40)
        
        input("Press Enter to continue...")
    
    def assign_volunteers(self):
        """Assign volunteers to requests"""
        self.clear_screen()
        self.display_header("Assign Volunteers")
        print("Volunteer assignment functionality would be implemented here.")
        input("Press Enter to continue...")
    
    def generate_reports(self):
        """Generate reports"""
        self.clear_screen()
        self.display_header("Generate Reports")
        print("Report generation functionality would be implemented here.")
        input("Press Enter to continue...")

