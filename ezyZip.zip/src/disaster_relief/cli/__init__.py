"""
User interface modules for the Disaster Relief Management System
"""

