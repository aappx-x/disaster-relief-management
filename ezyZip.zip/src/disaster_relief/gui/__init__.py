"""
GUI modules for the Disaster Relief Management System
"""

