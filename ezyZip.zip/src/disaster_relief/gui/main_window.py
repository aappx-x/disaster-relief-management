#!/usr/bin/env python3
"""
Main GUI window for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox, font
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.auth import AuthenticationManager
from disaster_relief.core.database import DatabaseManager

class DisasterReliefGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.auth = AuthenticationManager()
        self.db = DatabaseManager()
        self.current_user = None
        self.setup_main_window()
        self.show_login_screen()
    
    def setup_main_window(self):
        """Setup the main window with modern styling"""
        self.root.title("Disaster Relief Management System")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # Configure style
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Custom colors
        self.colors = {
            'primary': '#2c3e50',
            'secondary': '#3498db',
            'success': '#27ae60',
            'warning': '#f39c12',
            'danger': '#e74c3c',
            'light': '#ecf0f1',
            'dark': '#2c3e50'
        }
        
        # Configure styles
        self.style.configure('Title.TLabel', font=('Arial', 24, 'bold'), foreground=self.colors['primary'])
        self.style.configure('Heading.TLabel', font=('Arial', 16, 'bold'), foreground=self.colors['dark'])
        self.style.configure('Subheading.TLabel', font=('Arial', 12, 'bold'), foreground=self.colors['primary'])
        self.style.configure('Primary.TButton', font=('Arial', 12, 'bold'))
        self.style.configure('Success.TButton', font=('Arial', 12, 'bold'))
        self.style.configure('Warning.TButton', font=('Arial', 12, 'bold'))
        
        # Center the window
        self.center_window()
    
    def center_window(self):
        """Center the window on the screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def clear_window(self):
        """Clear all widgets from the window"""
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def show_login_screen(self):
        """Show the login screen"""
        self.clear_window()
        
        # Main frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(expand=True, fill='both')
        
        # Header
        header_frame = tk.Frame(main_frame, bg='#2c3e50', height=100)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Disaster Relief Management System", 
                              font=('Arial', 24, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(main_frame, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        # Login form
        login_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        login_frame.pack(expand=True, fill='both')
        
        # Login title
        login_title = tk.Label(login_frame, text="Login to System", 
                              font=('Arial', 18, 'bold'), fg='#2c3e50', bg='white')
        login_title.pack(pady=30)
        
        # Form fields
        form_frame = tk.Frame(login_frame, bg='white')
        form_frame.pack(expand=True, fill='both', padx=50, pady=20)
        
        # Email field
        tk.Label(form_frame, text="Email:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.email_var = tk.StringVar()
        email_entry = tk.Entry(form_frame, textvariable=self.email_var, font=('Arial', 12), 
                              width=30, relief='solid', bd=1)
        email_entry.pack(fill='x', pady=(0, 20))
        
        # Password field
        tk.Label(form_frame, text="Password:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.password_var = tk.StringVar()
        password_entry = tk.Entry(form_frame, textvariable=self.password_var, font=('Arial', 12), 
                                 width=30, show='*', relief='solid', bd=1)
        password_entry.pack(fill='x', pady=(0, 30))
        
        # Login button
        login_btn = tk.Button(form_frame, text="Login", command=self.handle_login, 
                                font=('Arial', 12, 'bold'), bg='#3498db', fg='white',
                                relief='flat', bd=0, padx=30, pady=10)
        login_btn.pack(pady=10)
        
        # Register buttons
        register_frame = tk.Frame(form_frame, bg='white')
        register_frame.pack(pady=20)
        
        tk.Label(register_frame, text="Don't have an account?", font=('Arial', 10), 
                fg='#7f8c8d', bg='white').pack()
        
        button_frame = tk.Frame(register_frame, bg='white')
        button_frame.pack(pady=10)
        
        user_btn = tk.Button(button_frame, text="Register as User", command=self.show_user_registration,
                           font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                           relief='flat', bd=0, padx=20, pady=5)
        user_btn.pack(side='left', padx=5)
        
        volunteer_btn = tk.Button(button_frame, text="Register as Volunteer", command=self.show_volunteer_registration,
                                font=('Arial', 10, 'bold'), bg='#f39c12', fg='white',
                                relief='flat', bd=0, padx=20, pady=5)
        volunteer_btn.pack(side='left', padx=5)
        
        # Default credentials info
        info_frame = tk.Frame(login_frame, bg='#ecf0f1', relief='solid', bd=1)
        info_frame.pack(fill='x', padx=20, pady=20)
        
        tk.Label(info_frame, text="Default Admin Credentials:", font=('Arial', 10, 'bold'), 
                fg='#2c3e50', bg='#ecf0f1').pack(pady=5)
        tk.Label(info_frame, text="Email: admin@disaster-relief.com", font=('Arial', 10), 
                fg='#7f8c8d', bg='#ecf0f1').pack()
        tk.Label(info_frame, text="Password: admin123", font=('Arial', 10), 
                fg='#7f8c8d', bg='#ecf0f1').pack(pady=(0, 5))
    
    def handle_login(self):
        """Handle login attempt"""
        email = self.email_var.get().strip()
        password = self.password_var.get().strip()
        
        if not email or not password:
            messagebox.showerror("Error", "Please enter both email and password")
            return
        
        user = self.auth.login(email, password)
        if user:
            self.current_user = user
            self.show_dashboard()
        else:
            messagebox.showerror("Error", "Invalid email or password")
    
    
    def show_user_registration(self):
        """Show user registration form"""
        self.show_registration_form("user")
    
    def show_volunteer_registration(self):
        """Show volunteer registration form"""
        self.show_registration_form("volunteer")
    
    def show_registration_form(self, user_type):
        """Show registration form"""
        self.clear_window()
        
        # Main frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(expand=True, fill='both')
        
        # Header
        header_frame = tk.Frame(main_frame, bg='#2c3e50', height=100)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Register as {user_type.title()}", 
                              font=('Arial', 24, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(main_frame, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        # Registration form
        reg_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        reg_frame.pack(expand=True, fill='both')

        # Create scrollable area within the registration card
        scroll_host = tk.Frame(reg_frame, bg='white')
        scroll_host.pack(expand=True, fill='both')
        scrollable = self.make_scrollable(scroll_host)

        # Form title
        reg_title = tk.Label(scrollable, text=f"{user_type.title()} Registration", 
                            font=('Arial', 18, 'bold'), fg='#2c3e50', bg='white')
        reg_title.pack(pady=30)

        # Form fields
        form_frame = tk.Frame(scrollable, bg='white')
        form_frame.pack(expand=True, fill='both', padx=50, pady=20)

        # Buttons row (kept inside scrollable so it's always reachable)
        button_frame = tk.Frame(scrollable, bg='white')
        button_frame.pack(pady=20)

        register_btn = tk.Button(button_frame, text="Register", command=lambda: self.handle_registration(user_type),
                               font=('Arial', 12, 'bold'), bg='#27ae60', fg='white',
                               relief='flat', bd=0, padx=30, pady=10)
        register_btn.pack(side='left', padx=10)

        back_btn = tk.Button(button_frame, text="Back to Login", command=self.show_login_screen,
                           font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                           relief='flat', bd=0, padx=30, pady=10)
        back_btn.pack(side='left', padx=10)

        # Username
        tk.Label(form_frame, text="Username:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.reg_username_var = tk.StringVar()
        username_entry = tk.Entry(form_frame, textvariable=self.reg_username_var, font=('Arial', 12), 
                width=30, relief='solid', bd=1)
        username_entry.pack(fill='x', pady=(0, 20))
        # Put keyboard focus in the Username box so it's obvious and ready to type
        username_entry.focus_set()
        
        # Email field
        tk.Label(form_frame, text="Email:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.reg_email_var = tk.StringVar()
        email_entry = tk.Entry(form_frame, textvariable=self.reg_email_var, font=('Arial', 12), 
                              width=30, relief='solid', bd=1)
        email_entry.pack(fill='x', pady=(0, 20))
        
        # Password field
        tk.Label(form_frame, text="Password:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.reg_password_var = tk.StringVar()
        password_entry = tk.Entry(form_frame, textvariable=self.reg_password_var, font=('Arial', 12), 
                                 width=30, show='*', relief='solid', bd=1)
        password_entry.pack(fill='x', pady=(0, 20))
        
        # Location field
        tk.Label(form_frame, text="Location:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.reg_location_var = tk.StringVar()
        location_entry = tk.Entry(form_frame, textvariable=self.reg_location_var, font=('Arial', 12), 
                                 width=30, relief='solid', bd=1)
        location_entry.pack(fill='x', pady=(0, 20))
        
        # Contact field
        tk.Label(form_frame, text="Contact:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.reg_contact_var = tk.StringVar()
        contact_entry = tk.Entry(form_frame, textvariable=self.reg_contact_var, font=('Arial', 12), 
                                 width=30, relief='solid', bd=1)
        contact_entry.pack(fill='x', pady=(0, 30))

        # Emergency type for user (if applicable)
        if user_type == "user":
            tk.Label(form_frame, text="Emergency Type:", font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
            self.reg_emergency_var = tk.StringVar()
            emergency_type_entry = tk.Entry(form_frame, textvariable=self.reg_emergency_var, font=('Arial', 12), 
                                           width=30, relief='solid', bd=1)
            emergency_type_entry.pack(fill='x', pady=(0, 20))

        # Skills and availability for volunteer
        if user_type == "volunteer":
            tk.Label(form_frame, text="Skills:", font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
            self.reg_skills_var = tk.StringVar()
            skills_entry = tk.Entry(form_frame, textvariable=self.reg_skills_var, font=('Arial', 12), 
                                    width=30, relief='solid', bd=1)
            skills_entry.pack(fill='x', pady=(0, 20))

            tk.Label(form_frame, text="Availability:", font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
            self.reg_availability_var = tk.StringVar()
            availability_entry = tk.Entry(form_frame, textvariable=self.reg_availability_var, font=('Arial', 12), 
                                          width=30, relief='solid', bd=1)
            availability_entry.pack(fill='x', pady=(0, 20))
    
    def handle_registration(self, user_type):
        """Handle registration"""
        username = self.reg_username_var.get().strip()
        email = self.reg_email_var.get().strip()
        password = self.reg_password_var.get().strip()
        location = self.reg_location_var.get().strip()
        contact = self.reg_contact_var.get().strip()
        
        if not all([username, email, password, location, contact]):
            messagebox.showerror("Error", "All fields are required")
            return
        
        if user_type == "user":
            emergency_type = self.reg_emergency_var.get().strip()
            if not emergency_type:
                messagebox.showerror("Error", "Please select an emergency type")
                return
            
            success = self.auth.register_user(username, email, password, emergency_type, location, contact)
        else:  # volunteer
            skills = self.reg_skills_var.get().strip()
            availability = self.reg_availability_var.get().strip()
            if not skills or not availability:
                messagebox.showerror("Error", "Skills and availability are required")
                return
            
            success = self.auth.register_volunteer(username, email, password, skills, availability, location, contact)
        
        if success:
            messagebox.showinfo("Success", f"{user_type.title()} registration successful!")
            self.show_login_screen()
        else:
            messagebox.showerror("Error", "Registration failed. Username or email may already exist.")
    
    def show_dashboard(self):
        """Show the appropriate dashboard based on user role"""
        role = self.current_user.get('role')
        
        if role == 'user':
            self.show_user_dashboard()
        elif role == 'volunteer':
            self.show_volunteer_dashboard()
        elif role == 'admin':
            self.show_admin_dashboard()
    
    def show_user_dashboard(self):
        """Show user dashboard"""
        self.clear_window()
        
        # Header
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"User Dashboard - Welcome {self.current_user['username']}", 
                              font=('Arial', 18, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(self.root, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Dashboard options
        options_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        options_frame.pack(expand=True, fill='both')
        
        tk.Label(options_frame, text="User Options", font=('Arial', 16, 'bold'), 
                fg='#2c3e50', bg='white').pack(pady=30)
        
        # Buttons
        button_frame = tk.Frame(options_frame, bg='white')
        button_frame.pack(expand=True, fill='both', padx=50, pady=30)
        
        submit_btn = tk.Button(button_frame, text="Submit Emergency Request", 
                              command=self.show_emergency_request_form,
                              font=('Arial', 12, 'bold'), bg='#e74c3c', fg='white',
                              relief='flat', bd=0, padx=20, pady=15, width=25)
        submit_btn.pack(pady=10)
        
        view_btn = tk.Button(button_frame, text="View My Requests", 
                           command=self.show_user_requests,
                           font=('Arial', 12, 'bold'), bg='#3498db', fg='white',
                           relief='flat', bd=0, padx=20, pady=15, width=25)
        view_btn.pack(pady=10)
        
        profile_btn = tk.Button(button_frame, text="Update Profile", 
                              command=self.show_profile_update,
                              font=('Arial', 12, 'bold'), bg='#f39c12', fg='white',
                              relief='flat', bd=0, padx=20, pady=15, width=25)
        profile_btn.pack(pady=10)
        
        logout_btn = tk.Button(button_frame, text="Logout", 
                              command=self.logout,
                              font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                              relief='flat', bd=0, padx=20, pady=15, width=25)
        logout_btn.pack(pady=10)
    
    def show_volunteer_dashboard(self):
        """Show volunteer dashboard"""
        self.clear_window()
        
        # Header
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Volunteer Dashboard - Welcome {self.current_user['username']}", 
                              font=('Arial', 18, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(self.root, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Dashboard options
        options_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        options_frame.pack(expand=True, fill='both')
        
        tk.Label(options_frame, text="Volunteer Options", font=('Arial', 16, 'bold'), 
                fg='#2c3e50', bg='white').pack(pady=30)
        
        # Buttons
        button_frame = tk.Frame(options_frame, bg='white')
        button_frame.pack(expand=True, fill='both', padx=50, pady=30)
        
        assignments_btn = tk.Button(button_frame, text="View My Assignments", 
                                  command=self.show_volunteer_assignments,
                                  font=('Arial', 12, 'bold'), bg='#27ae60', fg='white',
                                  relief='flat', bd=0, padx=20, pady=15, width=25)
        assignments_btn.pack(pady=10)
        
        availability_btn = tk.Button(button_frame, text="Update Availability", 
                                  command=self.show_availability_update,
                                  font=('Arial', 12, 'bold'), bg='#f39c12', fg='white',
                                  relief='flat', bd=0, padx=20, pady=15, width=25)
        availability_btn.pack(pady=10)
        
        logout_btn = tk.Button(button_frame, text="Logout", 
                              command=self.logout,
                              font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                              relief='flat', bd=0, padx=20, pady=15, width=25)
        logout_btn.pack(pady=10)
    
    def show_admin_dashboard(self):
        """Show admin dashboard"""
        self.clear_window()
        
        # Header
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Admin Dashboard - Welcome {self.current_user['username']}", 
                              font=('Arial', 18, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(self.root, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Dashboard options
        options_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        options_frame.pack(expand=True, fill='both')
        
        tk.Label(options_frame, text="Admin Options", font=('Arial', 16, 'bold'), 
                fg='#2c3e50', bg='white').pack(pady=30)
        
        # Buttons
        button_frame = tk.Frame(options_frame, bg='white')
        button_frame.pack(expand=True, fill='both', padx=50, pady=30)
        
        requests_btn = tk.Button(button_frame, text="Manage All Emergency Requests", 
                                command=self.show_admin_requests,
                                font=('Arial', 12, 'bold'), bg='#e74c3c', fg='white',
                                relief='flat', bd=0, padx=20, pady=15, width=25)
        requests_btn.pack(pady=10)
        
        inventory_btn = tk.Button(button_frame, text="Manage Inventory", 
                                 command=self.show_inventory_management,
                                 font=('Arial', 12, 'bold'), bg='#3498db', fg='white',
                                 relief='flat', bd=0, padx=20, pady=15, width=25)
        inventory_btn.pack(pady=10)
        
        volunteers_btn = tk.Button(button_frame, text="Manage Volunteers", 
                                  command=self.show_volunteer_management,
                                  font=('Arial', 12, 'bold'), bg='#27ae60', fg='white',
                                  relief='flat', bd=0, padx=20, pady=15, width=25)
        volunteers_btn.pack(pady=10)
        
        reports_btn = tk.Button(button_frame, text="Generate Reports", 
                               command=self.show_reports,
                               font=('Arial', 12, 'bold'), bg='#f39c12', fg='white',
                               relief='flat', bd=0, padx=20, pady=15, width=25)
        reports_btn.pack(pady=10)
        
        logout_btn = tk.Button(button_frame, text="Logout", 
                              command=self.logout,
                              font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                              relief='flat', bd=0, padx=20, pady=15, width=25)
        logout_btn.pack(pady=10)
    
    def show_emergency_request_form(self):
        """Show emergency request form"""
        from .emergency_request_form import EmergencyRequestFormGUI
        EmergencyRequestFormGUI(self.root, self.current_user)
    
    def show_user_requests(self):
        """Show user's requests"""
        from .request_management import RequestManagementGUI
        RequestManagementGUI(self.root, self.current_user)
    
    def show_profile_update(self):
        """Show profile update form"""
        messagebox.showinfo("Info", "Profile update form would be implemented here")
    
    def show_available_requests(self):
        """Show available requests for volunteers"""
        from .request_management import RequestManagementGUI
        RequestManagementGUI(self.root, self.current_user)
    
    def show_volunteer_assignments(self):
        """Show volunteer assignments"""
        from .volunteer_assignments import VolunteerAssignmentsGUI
        VolunteerAssignmentsGUI(self.root, self.current_user)
    
    def show_availability_update(self):
        """Show availability update form"""
        messagebox.showinfo("Info", "Availability update form would be implemented here")
    
    def show_admin_requests(self):
        """Show admin request management"""
        from .request_management import RequestManagementGUI
        RequestManagementGUI(self.root, self.current_user)
    
    def show_inventory_management(self):
        """Show inventory management"""
        from .inventory_management import InventoryManagementGUI
        InventoryManagementGUI(self.root, self.current_user)
    
    def show_volunteer_management(self):
        """Show volunteer management"""
        from .volunteer_management import VolunteerManagementGUI
        VolunteerManagementGUI(self.root, self.current_user)
    
    def show_reports(self):
        """Show reports"""
        from .reports import ReportsGUI
        ReportsGUI(self.root, self.current_user)
    
    def logout(self):
        """Logout user"""
        self.auth.logout()
        self.current_user = None
        self.show_login_screen()
    
    def run(self):
        """Run the GUI application"""
        self.root.mainloop()

    def make_scrollable(self, parent):
        """Create a vertical scrollable frame inside parent and return the inner frame.
        This ensures content (like long forms) is reachable on smaller screens."""
        container = tk.Frame(parent, bg=parent.cget('bg'))
        container.pack(expand=True, fill='both')

        canvas = tk.Canvas(container, highlightthickness=0, bg=parent.cget('bg'))
        vscroll = ttk.Scrollbar(container, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vscroll.set)

        canvas.pack(side='left', fill='both', expand=True)
        vscroll.pack(side='right', fill='y')

        inner = tk.Frame(canvas, bg='white')
        inner_id = canvas.create_window((0, 0), window=inner, anchor='nw')

        def on_configure(event):
            canvas.configure(scrollregion=canvas.bbox('all'))
            # Make the inner frame width follow the canvas width
            canvas.itemconfigure(inner_id, width=canvas.winfo_width())
        inner.bind('<Configure>', on_configure)

        # Mouse wheel support
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        canvas.bind_all('<MouseWheel>', _on_mousewheel)

        return inner

def main():
    """Main entry point for GUI application"""
    try:
        app = DisasterReliefGUI()
        app.run()
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

if __name__ == "__main__":
    main()
