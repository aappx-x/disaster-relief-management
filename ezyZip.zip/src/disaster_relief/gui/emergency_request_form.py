#!/usr/bin/env python3
"""
Emergency request form GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class EmergencyRequestFormGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the emergency request form interface"""
        self.window = tk.Toplevel(self.parent)
        self.window.title("Submit Emergency Request")
        self.window.geometry("600x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Submit Emergency Request", 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Form frame
        form_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        form_frame.pack(expand=True, fill='both')
        
        # Form fields
        fields_frame = tk.Frame(form_frame, bg='white')
        fields_frame.pack(expand=True, fill='both', padx=40, pady=30)
        
        # Request Type
        tk.Label(fields_frame, text="Request Type:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.request_type_var = tk.StringVar()
        request_type_combo = ttk.Combobox(fields_frame, textvariable=self.request_type_var, 
                                         font=('Arial', 12), width=50)
        request_type_combo['values'] = ('Food', 'Water', 'Medical Supplies', 'Shelter', 'Clothing', 'Transportation', 'Other')
        request_type_combo.pack(fill='x', pady=(0, 20))
        
        # Description
        tk.Label(fields_frame, text="Description:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.description_var = tk.StringVar()
        description_entry = tk.Entry(fields_frame, textvariable=self.description_var, font=('Arial', 12), 
                                    width=50, relief='solid', bd=1)
        description_entry.pack(fill='x', pady=(0, 20))
        
        # Priority
        tk.Label(fields_frame, text="Priority:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.priority_var = tk.StringVar(value="medium")
        priority_frame = tk.Frame(fields_frame, bg='white')
        priority_frame.pack(fill='x', pady=(0, 20))
        
        tk.Radiobutton(priority_frame, text="Low", variable=self.priority_var, value="low", 
                      font=('Arial', 12), fg='#27ae60', bg='white').pack(side='left', padx=(0, 20))
        tk.Radiobutton(priority_frame, text="Medium", variable=self.priority_var, value="medium", 
                      font=('Arial', 12), fg='#f39c12', bg='white').pack(side='left', padx=(0, 20))
        tk.Radiobutton(priority_frame, text="High", variable=self.priority_var, value="high", 
                      font=('Arial', 12), fg='#e74c3c', bg='white').pack(side='left')
        
        # Location
        tk.Label(fields_frame, text="Location:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.location_var = tk.StringVar()
        location_entry = tk.Entry(fields_frame, textvariable=self.location_var, font=('Arial', 12), 
                                 width=50, relief='solid', bd=1)
        location_entry.pack(fill='x', pady=(0, 20))
        
        # Contact Information
        tk.Label(fields_frame, text="Contact Information:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.contact_var = tk.StringVar()
        contact_entry = tk.Entry(fields_frame, textvariable=self.contact_var, font=('Arial', 12), 
                                width=50, relief='solid', bd=1)
        contact_entry.pack(fill='x', pady=(0, 30))
        
        # Buttons
        button_frame = tk.Frame(fields_frame, bg='white')
        button_frame.pack(fill='x')
        
        submit_btn = tk.Button(button_frame, text="Submit Request", command=self.submit_request,
                              font=('Arial', 12, 'bold'), bg='#e74c3c', fg='white',
                              relief='flat', bd=0, padx=30, pady=10)
        submit_btn.pack(side='left', padx=(0, 10))
        
        cancel_btn = tk.Button(button_frame, text="Cancel", command=self.window.destroy,
                              font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                              relief='flat', bd=0, padx=30, pady=10)
        cancel_btn.pack(side='left', padx=(0, 10))
    
    def submit_request(self):
        """Submit the emergency request"""
        request_type = self.request_type_var.get().strip()
        description = self.description_var.get().strip()
        priority = self.priority_var.get()
        location = self.location_var.get().strip()
        contact = self.contact_var.get().strip()
        
        if not all([request_type, description, location, contact]):
            messagebox.showerror("Error", "All fields are required")
            return
        
        # Submit request to database
        request_id = self.db.create_emergency_request(
            self.current_user['id'], request_type, description, priority, location, contact
        )
        
        if request_id:
            messagebox.showinfo("Success", f"Emergency request submitted successfully!\nRequest ID: {request_id}")
            self.window.destroy()
        else:
            messagebox.showerror("Error", "Failed to submit emergency request")

