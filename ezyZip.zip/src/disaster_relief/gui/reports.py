#!/usr/bin/env python3
"""
Reports GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class ReportsGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the reports interface"""
        self.window = tk.Toplevel(self.parent)
        self.window.title("System Reports")
        self.window.geometry("1000x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="System Reports", 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Report selection frame
        selection_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        selection_frame.pack(fill='x', pady=(0, 10))
        
        # Report buttons
        buttons_frame = tk.Frame(selection_frame, bg='white')
        buttons_frame.pack(fill='x', padx=20, pady=20)
        
        tk.Label(buttons_frame, text="Select Report Type:", font=('Arial', 14, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 15))
        
        # Report buttons
        report_buttons = [
            ("Emergency Requests Summary", self.show_requests_summary, '#e74c3c'),
            ("Inventory Status", self.show_inventory_report, '#3498db'),
            ("Volunteer Status", self.show_volunteer_report, '#27ae60'),
            ("System Statistics", self.show_system_stats, '#f39c12'),
            ("High Priority Requests", self.show_high_priority_requests, '#e67e22')
        ]
        
        for i, (text, command, color) in enumerate(report_buttons):
            btn = tk.Button(buttons_frame, text=text, command=command,
                           font=('Arial', 12, 'bold'), bg=color, fg='white',
                           relief='flat', bd=0, padx=20, pady=10, width=25)
            btn.pack(pady=5)
        
        # Report display frame
        self.report_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        self.report_frame.pack(expand=True, fill='both')
        
        # Initial message
        initial_label = tk.Label(self.report_frame, text="Select a report type to view detailed information", 
                                font=('Arial', 14), fg='#7f8c8d', bg='white')
        initial_label.pack(expand=True)
    
    def clear_report_frame(self):
        """Clear the report display frame"""
        for widget in self.report_frame.winfo_children():
            widget.destroy()
    
    def show_requests_summary(self):
        """Show emergency requests summary report"""
        self.clear_report_frame()
        
        # Header
        header_label = tk.Label(self.report_frame, text="Emergency Requests Summary", 
                               font=('Arial', 16, 'bold'), fg='#2c3e50', bg='white')
        header_label.pack(pady=20)
        
        # Get requests data
        requests = self.db.get_emergency_requests()
        
        # Summary statistics
        total_requests = len(requests)
        pending_requests = len([r for r in requests if r['status'] == 'pending'])
        approved_requests = len([r for r in requests if r['status'] == 'approved'])
        completed_requests = len([r for r in requests if r['status'] == 'completed'])
        rejected_requests = len([r for r in requests if r['status'] == 'rejected'])
        
        # Statistics frame
        stats_frame = tk.Frame(self.report_frame, bg='white')
        stats_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Statistics labels
        stats = [
            ("Total Requests:", str(total_requests)),
            ("Pending:", str(pending_requests)),
            ("Approved:", str(approved_requests)),
            ("Completed:", str(completed_requests)),
            ("Rejected:", str(rejected_requests))
        ]
        
        for i, (label, value) in enumerate(stats):
            tk.Label(stats_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(stats_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Recent requests table
        if requests:
            tk.Label(stats_frame, text="Recent Requests:", font=('Arial', 14, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=len(stats)+1, column=0, columnspan=2, sticky='w', pady=(20, 10))
            
            # Create treeview for recent requests
            columns = ('ID', 'User', 'Type', 'Priority', 'Status', 'Created')
            tree = ttk.Treeview(stats_frame, columns=columns, show='headings', height=8)
            
            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, width=100, anchor='center')
            
            # Add recent requests (last 10)
            recent_requests = requests[:10]
            for req in recent_requests:
                tree.insert('', 'end', values=(
                    req['id'],
                    req['username'],
                    req['request_type'],
                    req['priority'],
                    req['status'],
                    req['created_at'][:10]
                ))
            
            tree.grid(row=len(stats)+2, column=0, columnspan=2, sticky='ew', pady=10)
    
    def show_inventory_report(self):
        """Show inventory status report"""
        self.clear_report_frame()
        
        # Header
        header_label = tk.Label(self.report_frame, text="Inventory Status Report", 
                               font=('Arial', 16, 'bold'), fg='#2c3e50', bg='white')
        header_label.pack(pady=20)
        
        # Get inventory data
        inventory = self.db.get_inventory()
        
        # Summary statistics
        total_items = len(inventory)
        total_quantity = sum(item['quantity'] for item in inventory)
        categories = {}
        for item in inventory:
            category = item['category']
            if category not in categories:
                categories[category] = 0
            categories[category] += item['quantity']
        
        # Statistics frame
        stats_frame = tk.Frame(self.report_frame, bg='white')
        stats_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Statistics labels
        stats = [
            ("Total Items:", str(total_items)),
            ("Total Quantity:", str(total_quantity)),
            ("Categories:", str(len(categories)))
        ]
        
        for i, (label, value) in enumerate(stats):
            tk.Label(stats_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(stats_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Category breakdown
        if categories:
            tk.Label(stats_frame, text="Category Breakdown:", font=('Arial', 14, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=len(stats)+1, column=0, columnspan=2, sticky='w', pady=(20, 10))
            
            row = len(stats) + 2
            for category, quantity in categories.items():
                tk.Label(stats_frame, text=f"{category}:", font=('Arial', 12, 'bold'), 
                        fg='#2c3e50', bg='white').grid(row=row, column=0, sticky='w', pady=2, padx=(0, 20))
                tk.Label(stats_frame, text=str(quantity), font=('Arial', 12), 
                        fg='#7f8c8d', bg='white').grid(row=row, column=1, sticky='w', pady=2)
                row += 1
    
    def show_volunteer_report(self):
        """Show volunteer status report"""
        self.clear_report_frame()
        
        # Header
        header_label = tk.Label(self.report_frame, text="Volunteer Status Report", 
                               font=('Arial', 16, 'bold'), fg='#2c3e50', bg='white')
        header_label.pack(pady=20)
        
        # Get volunteers data
        volunteers = self.db.get_volunteers()
        
        # Summary statistics
        total_volunteers = len(volunteers)
        active_volunteers = len([v for v in volunteers if v['status'] == 'active'])
        inactive_volunteers = len([v for v in volunteers if v['status'] == 'inactive'])
        
        # Statistics frame
        stats_frame = tk.Frame(self.report_frame, bg='white')
        stats_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Statistics labels
        stats = [
            ("Total Volunteers:", str(total_volunteers)),
            ("Active:", str(active_volunteers)),
            ("Inactive:", str(inactive_volunteers))
        ]
        
        for i, (label, value) in enumerate(stats):
            tk.Label(stats_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(stats_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Volunteer list
        if volunteers:
            tk.Label(stats_frame, text="Volunteer List:", font=('Arial', 14, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=len(stats)+1, column=0, columnspan=2, sticky='w', pady=(20, 10))
            
            # Create treeview for volunteers
            columns = ('ID', 'Username', 'Skills', 'Availability', 'Status')
            tree = ttk.Treeview(stats_frame, columns=columns, show='headings', height=8)
            
            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, width=120, anchor='center')
            
            # Add volunteers
            for vol in volunteers:
                tree.insert('', 'end', values=(
                    vol['id'],
                    vol['username'],
                    vol['skills'][:20] + '...' if len(vol['skills']) > 20 else vol['skills'],
                    vol['availability'],
                    vol['status']
                ))
            
            tree.grid(row=len(stats)+2, column=0, columnspan=2, sticky='ew', pady=10)
    
    def show_system_stats(self):
        """Show system statistics"""
        self.clear_report_frame()
        
        # Header
        header_label = tk.Label(self.report_frame, text="System Statistics", 
                               font=('Arial', 16, 'bold'), fg='#2c3e50', bg='white')
        header_label.pack(pady=20)
        
        # Get all data
        requests = self.db.get_emergency_requests()
        inventory = self.db.get_inventory()
        volunteers = self.db.get_volunteers()
        
        # Statistics frame
        stats_frame = tk.Frame(self.report_frame, bg='white')
        stats_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # System statistics
        stats = [
            ("Total Emergency Requests:", str(len(requests))),
            ("Total Inventory Items:", str(len(inventory))),
            ("Total Volunteers:", str(len(volunteers))),
            ("Total Inventory Quantity:", str(sum(item['quantity'] for item in inventory))),
            ("Active Volunteers:", str(len([v for v in volunteers if v['status'] == 'active']))),
            ("Pending Requests:", str(len([r for r in requests if r['status'] == 'pending'])))
        ]
        
        for i, (label, value) in enumerate(stats):
            tk.Label(stats_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(stats_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
    
    def show_high_priority_requests(self):
        """Show high priority requests"""
        self.clear_report_frame()
        
        # Header
        header_label = tk.Label(self.report_frame, text="High Priority Requests", 
                               font=('Arial', 16, 'bold'), fg='#2c3e50', bg='white')
        header_label.pack(pady=20)
        
        # Get high priority requests
        requests = self.db.get_emergency_requests()
        high_priority = [r for r in requests if r['priority'] == 'high']
        
        # Statistics frame
        stats_frame = tk.Frame(self.report_frame, bg='white')
        stats_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # High priority statistics
        stats = [
            ("Total High Priority Requests:", str(len(high_priority))),
            ("Pending High Priority:", str(len([r for r in high_priority if r['status'] == 'pending']))),
            ("Approved High Priority:", str(len([r for r in high_priority if r['status'] == 'approved']))),
            ("Completed High Priority:", str(len([r for r in high_priority if r['status'] == 'completed'])))
        ]
        
        for i, (label, value) in enumerate(stats):
            tk.Label(stats_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(stats_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # High priority requests table
        if high_priority:
            tk.Label(stats_frame, text="High Priority Requests:", font=('Arial', 14, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=len(stats)+1, column=0, columnspan=2, sticky='w', pady=(20, 10))
            
            # Create treeview for high priority requests
            columns = ('ID', 'User', 'Type', 'Status', 'Location', 'Created')
            tree = ttk.Treeview(stats_frame, columns=columns, show='headings', height=8)
            
            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, width=120, anchor='center')
            
            # Add high priority requests
            for req in high_priority:
                tree.insert('', 'end', values=(
                    req['id'],
                    req['username'],
                    req['request_type'],
                    req['status'],
                    req['location'],
                    req['created_at'][:10]
                ))
            
            tree.grid(row=len(stats)+2, column=0, columnspan=2, sticky='ew', pady=10)

