#!/usr/bin/env python3
"""
Inventory management GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class InventoryManagementGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the inventory management interface"""
        self.window = tk.Toplevel(self.parent)
        self.window.title("Inventory Management")
        self.window.geometry("1200x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Inventory Management", 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Controls frame
        controls_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        controls_frame.pack(fill='x', pady=(0, 10))
        
        # Action buttons
        action_frame = tk.Frame(controls_frame, bg='white')
        action_frame.pack(fill='x', padx=20, pady=15)
        
        add_btn = tk.Button(action_frame, text="Add New Item", command=self.show_add_item_form,
                           font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                           relief='flat', bd=0, padx=15, pady=5)
        add_btn.pack(side='left', padx=(0, 10))
        
        update_btn = tk.Button(action_frame, text="Update Selected", command=self.update_selected_item,
                              font=('Arial', 10, 'bold'), bg='#3498db', fg='white',
                              relief='flat', bd=0, padx=15, pady=5)
        update_btn.pack(side='left', padx=(0, 10))
        
        refresh_btn = tk.Button(action_frame, text="Refresh", command=self.load_inventory,
                               font=('Arial', 10, 'bold'), bg='#f39c12', fg='white',
                               relief='flat', bd=0, padx=15, pady=5)
        refresh_btn.pack(side='left', padx=(0, 10))
        
        # Inventory list
        list_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        list_frame.pack(expand=True, fill='both')
        
        # Treeview for inventory
        columns = ('ID', 'Item Name', 'Category', 'Quantity', 'Unit', 'Location', 'Status', 'Expiry')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        # Configure columns
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, anchor='center')
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(list_frame, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack treeview and scrollbars
        self.tree.pack(side='left', fill='both', expand=True)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar.pack(side='bottom', fill='x')
        
        # Bind double-click event
        self.tree.bind('<Double-1>', self.view_item_details)
        
        # Load initial data
        self.load_inventory()
    
    def load_inventory(self):
        """Load inventory from database"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Get inventory from database
        inventory = self.db.get_inventory()
        
        # Add items to treeview
        for item in inventory:
            expiry = item['expiry_date'] if item['expiry_date'] else 'N/A'
            self.tree.insert('', 'end', values=(
                item['id'],
                item['item_name'],
                item['category'],
                item['quantity'],
                item['unit'],
                item['location'],
                item['status'],
                expiry
            ))
    
    def show_add_item_form(self):
        """Show add new item form"""
        form_window = tk.Toplevel(self.window)
        form_window.title("Add New Inventory Item")
        form_window.geometry("500x600")
        form_window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(form_window, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Add New Inventory Item", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(form_window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Form frame
        form_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        form_frame.pack(expand=True, fill='both')
        
        # Form fields
        fields_frame = tk.Frame(form_frame, bg='white')
        fields_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Item Name
        tk.Label(fields_frame, text="Item Name:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.item_name_var = tk.StringVar()
        tk.Entry(fields_frame, textvariable=self.item_name_var, font=('Arial', 12), 
                width=40, relief='solid', bd=1).pack(fill='x', pady=(0, 20))
        
        # Category
        tk.Label(fields_frame, text="Category:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.category_var = tk.StringVar()
        category_combo = ttk.Combobox(fields_frame, textvariable=self.category_var, 
                                     font=('Arial', 12), width=37)
        category_combo['values'] = ('hydration', 'medical', 'shelter', 'nutrition', 'equipment', 'clothing', 'other')
        category_combo.pack(fill='x', pady=(0, 20))
        
        # Quantity
        tk.Label(fields_frame, text="Quantity:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.quantity_var = tk.StringVar()
        tk.Entry(fields_frame, textvariable=self.quantity_var, font=('Arial', 12), 
                width=40, relief='solid', bd=1).pack(fill='x', pady=(0, 20))
        
        # Unit
        tk.Label(fields_frame, text="Unit:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.unit_var = tk.StringVar()
        unit_combo = ttk.Combobox(fields_frame, textvariable=self.unit_var, 
                                 font=('Arial', 12), width=37)
        unit_combo['values'] = ('pieces', 'kg', 'liters', 'kits', 'meals', 'units', 'packs', 'boxes')
        unit_combo.pack(fill='x', pady=(0, 20))
        
        # Location
        tk.Label(fields_frame, text="Storage Location:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.location_var = tk.StringVar()
        tk.Entry(fields_frame, textvariable=self.location_var, font=('Arial', 12), 
                width=40, relief='solid', bd=1).pack(fill='x', pady=(0, 20))
        
        # Expiry Date
        tk.Label(fields_frame, text="Expiry Date (YYYY-MM-DD, optional):", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', pady=(0, 5))
        self.expiry_var = tk.StringVar()
        tk.Entry(fields_frame, textvariable=self.expiry_var, font=('Arial', 12), 
                width=40, relief='solid', bd=1).pack(fill='x', pady=(0, 30))
        
        # Buttons
        button_frame = tk.Frame(fields_frame, bg='white')
        button_frame.pack(fill='x')
        
        save_btn = tk.Button(button_frame, text="Save Item", command=lambda: self.save_item(form_window),
                            font=('Arial', 12, 'bold'), bg='#27ae60', fg='white',
                            relief='flat', bd=0, padx=30, pady=10)
        save_btn.pack(side='left', padx=(0, 10))
        
        cancel_btn = tk.Button(button_frame, text="Cancel", command=form_window.destroy,
                                 font=('Arial', 12, 'bold'), bg='#95a5a6', fg='white',
                                 relief='flat', bd=0, padx=30, pady=10)
        cancel_btn.pack(side='left', padx=(0, 10))
    
    def save_item(self, form_window):
        """Save new inventory item"""
        item_name = self.item_name_var.get().strip()
        category = self.category_var.get().strip()
        quantity = self.quantity_var.get().strip()
        unit = self.unit_var.get().strip()
        location = self.location_var.get().strip()
        expiry = self.expiry_var.get().strip() if self.expiry_var.get().strip() else None
        
        if not all([item_name, category, quantity, unit, location]):
            messagebox.showerror("Error", "All required fields must be filled")
            return
        
        try:
            quantity = int(quantity)
        except ValueError:
            messagebox.showerror("Error", "Quantity must be a number")
            return
        
        success = self.db.add_inventory_item(item_name, category, quantity, unit, location, expiry)
        
        if success:
            messagebox.showinfo("Success", "Inventory item added successfully!")
            form_window.destroy()
            self.load_inventory()
        else:
            messagebox.showerror("Error", "Failed to add inventory item")
    
    def view_item_details(self, event):
        """View detailed information about an item"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        item_id = item['values'][0]
        
        # Get full item details
        inventory = self.db.get_inventory()
        item_data = next((item for item in inventory if item['id'] == int(item_id)), None)
        
        if item_data:
            self.show_item_details(item_data)
    
    def show_item_details(self, item_data):
        """Show detailed item information"""
        details_window = tk.Toplevel(self.window)
        details_window.title(f"Item Details - {item_data['item_name']}")
        details_window.geometry("500x400")
        details_window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(details_window, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Item Details - {item_data['item_name']}", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(details_window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Details frame
        details_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        details_frame.pack(expand=True, fill='both')
        
        # Item information
        info_frame = tk.Frame(details_frame, bg='white')
        info_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Create labels for item details
        details = [
            ("Item ID:", str(item_data['id'])),
            ("Item Name:", item_data['item_name']),
            ("Category:", item_data['category']),
            ("Quantity:", str(item_data['quantity'])),
            ("Unit:", item_data['unit']),
            ("Location:", item_data['location']),
            ("Status:", item_data['status']),
            ("Expiry Date:", item_data['expiry_date'] if item_data['expiry_date'] else 'N/A')
        ]
        
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(info_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Action buttons
        action_frame = tk.Frame(details_frame, bg='white')
        action_frame.pack(fill='x', padx=30, pady=20)
        
        update_btn = tk.Button(action_frame, text="Update Quantity", command=lambda: self.update_quantity(item_data['id']),
                              font=('Arial', 10, 'bold'), bg='#3498db', fg='white',
                              relief='flat', bd=0, padx=20, pady=5)
        update_btn.pack(side='left', padx=(0, 10))
        
        close_btn = tk.Button(action_frame, text="Close", command=details_window.destroy,
                             font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                             relief='flat', bd=0, padx=20, pady=5)
        close_btn.pack(side='right')
    
    def update_quantity(self, item_id):
        """Update item quantity"""
        # Get new quantity from user
        new_quantity = tk.simpledialog.askinteger("Update Quantity", "Enter new quantity:", minvalue=0)
        
        if new_quantity is not None:
            success = self.db.update_inventory_quantity(item_id, new_quantity)
            if success:
                messagebox.showinfo("Success", f"Quantity updated to {new_quantity}")
                self.load_inventory()
            else:
                messagebox.showerror("Error", "Failed to update quantity")
    
    def update_selected_item(self):
        """Update selected item"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select an item to update")
            return
        
        item = self.tree.item(selection[0])
        item_id = item['values'][0]
        
        # Get new quantity from user
        new_quantity = tk.simpledialog.askinteger("Update Quantity", "Enter new quantity:", minvalue=0)
        
        if new_quantity is not None:
            success = self.db.update_inventory_quantity(int(item_id), new_quantity)
            if success:
                messagebox.showinfo("Success", f"Item quantity updated to {new_quantity}")
                self.load_inventory()
            else:
                messagebox.showerror("Error", "Failed to update quantity")

