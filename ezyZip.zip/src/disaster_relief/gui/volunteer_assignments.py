#!/usr/bin/env python3
"""
Volunteer assignments GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class VolunteerAssignmentsGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the volunteer assignments interface"""
        self.window = tk.Toplevel(self.parent)
        self.window.title("My Assignments")
        self.window.geometry("1000x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="My Assignments", 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Controls frame
        controls_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        controls_frame.pack(fill='x', pady=(0, 10))
        
        # Filter controls
        filter_frame = tk.Frame(controls_frame, bg='white')
        filter_frame.pack(fill='x', padx=20, pady=15)
        
        tk.Label(filter_frame, text="Filter by Status:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(side='left', padx=(0, 10))
        
        self.status_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(filter_frame, textvariable=self.status_var, 
                                   font=('Arial', 12), width=15)
        status_combo['values'] = ('All', 'assigned', 'accepted', 'pending')
        status_combo.pack(side='left', padx=(0, 20))
        
        filter_btn = tk.Button(filter_frame, text="Filter", command=self.filter_assignments,
                              font=('Arial', 10, 'bold'), bg='#3498db', fg='white',
                              relief='flat', bd=0, padx=15, pady=5)
        filter_btn.pack(side='left', padx=(0, 10))
        
        refresh_btn = tk.Button(filter_frame, text="Refresh", command=self.load_assignments,
                               font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                               relief='flat', bd=0, padx=15, pady=5)
        refresh_btn.pack(side='left', padx=(0, 10))
        
        # Assignments list
        list_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        list_frame.pack(expand=True, fill='both')
        
        # Treeview for assignments
        columns = ('ID', 'Type', 'Priority', 'Status', 'Location', 'Created', 'Admin Notes')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        # Configure columns
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, anchor='center')
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(list_frame, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack treeview and scrollbars
        self.tree.pack(side='left', fill='both', expand=True)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar.pack(side='bottom', fill='x')
        
        # Bind double-click event
        self.tree.bind('<Double-1>', self.view_assignment_details)
        
        # Load initial data
        self.load_assignments()
    
    def load_assignments(self):
        """Load assignments from database"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Get assignments for current volunteer
        volunteer_id = self.current_user.get('id')
        status_filter = self.status_var.get()
        
        assignments = self.db.get_volunteer_assignments(volunteer_id)
        
        # Filter by status if not "All"
        if status_filter != "All":
            assignments = [assignment for assignment in assignments if assignment['status'] == status_filter]
        
        # Add assignments to treeview
        for assignment in assignments:
            admin_notes = assignment.get('admin_notes', '') or 'None'
            if len(admin_notes) > 30:
                admin_notes = admin_notes[:30] + '...'
            
            self.tree.insert('', 'end', values=(
                assignment['id'],
                assignment['request_type'],
                assignment['priority'],
                assignment['status'],
                assignment['location'],
                assignment['created_at'][:10],  # Show only date
                admin_notes
            ))
    
    def filter_assignments(self):
        """Filter assignments by status"""
        self.load_assignments()
    
    def view_assignment_details(self, event):
        """View detailed information about an assignment"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        assignment_id = item['values'][0]
        
        # Get full assignment details
        assignments = self.db.get_volunteer_assignments(self.current_user.get('id'))
        assignment = next((assign for assign in assignments if assign['id'] == assignment_id), None)
        
        if assignment:
            self.show_assignment_details(assignment)
    
    def show_assignment_details(self, assignment):
        """Show detailed assignment information"""
        details_window = tk.Toplevel(self.window)
        details_window.title(f"Assignment Details - #{assignment['id']}")
        details_window.geometry("600x500")
        details_window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(details_window, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Assignment #{assignment['id']} Details", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(details_window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Details frame
        details_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        details_frame.pack(expand=True, fill='both')
        
        # Assignment information
        info_frame = tk.Frame(details_frame, bg='white')
        info_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Create labels for assignment details
        details = [
            ("Assignment ID:", str(assignment['id'])),
            ("Request Type:", assignment['request_type']),
            ("Description:", assignment['description']),
            ("Priority:", assignment['priority']),
            ("Status:", assignment['status']),
            ("Location:", assignment['location']),
            ("Contact Info:", assignment['contact_info']),
            ("Created:", assignment['created_at']),
            ("Admin Notes:", assignment.get('admin_notes', 'None'))
        ]
        
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(info_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Action buttons for assigned tasks
        if assignment['status'] == 'assigned':
            action_frame = tk.Frame(details_frame, bg='white')
            action_frame.pack(fill='x', padx=30, pady=20)
            
            accept_btn = tk.Button(action_frame, text="Accept Assignment", 
                                 command=lambda: self.respond_to_assignment(assignment['id'], 'accept'),
                                 font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                                 relief='flat', bd=0, padx=20, pady=5)
            accept_btn.pack(side='left', padx=(0, 10))
            
            reject_btn = tk.Button(action_frame, text="Reject Assignment", 
                                 command=lambda: self.respond_to_assignment(assignment['id'], 'reject'),
                                 font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                                 relief='flat', bd=0, padx=20, pady=5)
            reject_btn.pack(side='left', padx=(0, 10))
            
            close_btn = tk.Button(action_frame, text="Close", command=details_window.destroy,
                                font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                                relief='flat', bd=0, padx=20, pady=5)
            close_btn.pack(side='right')
        else:
            close_btn = tk.Button(details_frame, text="Close", command=details_window.destroy,
                                 font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                                 relief='flat', bd=0, padx=20, pady=5)
            close_btn.pack(pady=20)
    
    def respond_to_assignment(self, assignment_id, response):
        """Handle volunteer's response to assignment"""
        volunteer_id = self.current_user.get('id')
        
        success = self.db.volunteer_respond_to_assignment(assignment_id, volunteer_id, response)
        if success:
            if response == 'accept':
                messagebox.showinfo("Success", f"Assignment #{assignment_id} accepted successfully!")
            else:
                messagebox.showinfo("Success", f"Assignment #{assignment_id} rejected. It has been returned to pending status.")
            self.load_assignments()
        else:
            messagebox.showerror("Error", "Failed to respond to assignment")
