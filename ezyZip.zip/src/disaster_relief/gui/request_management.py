#!/usr/bin/env python3
"""
Request management GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class RequestManagementGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the request management interface"""
        self.window = tk.Toplevel(self.parent)
        
        # Set title based on user role
        user_role = self.current_user.get('role')
        if user_role == 'admin':
            self.window.title("Emergency Request Management - Admin View")
            title_text = "Emergency Request Management - All Requests"
        elif user_role == 'user':
            self.window.title("My Emergency Requests")
            title_text = "My Emergency Requests"
        elif user_role == 'volunteer':
            self.window.title("Available Emergency Requests")
            title_text = "Available Emergency Requests"
        else:
            self.window.title("Emergency Request Management")
            title_text = "Emergency Request Management"
        
        self.window.geometry("1000x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=title_text, 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Controls frame
        controls_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        controls_frame.pack(fill='x', pady=(0, 10))
        
        # Filter controls
        filter_frame = tk.Frame(controls_frame, bg='white')
        filter_frame.pack(fill='x', padx=20, pady=15)
        
        tk.Label(filter_frame, text="Filter by Status:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(side='left', padx=(0, 10))
        
        self.status_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(filter_frame, textvariable=self.status_var, 
                                   font=('Arial', 12), width=15)
        status_combo['values'] = ('All', 'pending', 'approved', 'in_progress', 'completed', 'rejected')
        status_combo.pack(side='left', padx=(0, 20))
        
        filter_btn = tk.Button(filter_frame, text="Filter", command=self.filter_requests,
                              font=('Arial', 10, 'bold'), bg='#3498db', fg='white',
                              relief='flat', bd=0, padx=15, pady=5)
        filter_btn.pack(side='left', padx=(0, 10))
        
        refresh_btn = tk.Button(filter_frame, text="Refresh", command=self.load_requests,
                               font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                               relief='flat', bd=0, padx=15, pady=5)
        refresh_btn.pack(side='left', padx=(0, 10))
        
        # Action buttons
        action_frame = tk.Frame(controls_frame, bg='white')
        action_frame.pack(fill='x', padx=20, pady=(0, 15))
        
        if self.current_user.get('role') == 'admin':
            approve_btn = tk.Button(action_frame, text="Approve Selected", command=self.approve_selected,
                                  font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                                  relief='flat', bd=0, padx=15, pady=5)
            approve_btn.pack(side='left', padx=(0, 10))
            
            reject_btn = tk.Button(action_frame, text="Reject Selected", command=self.reject_selected,
                                 font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                                 relief='flat', bd=0, padx=15, pady=5)
            reject_btn.pack(side='left', padx=(0, 10))
            
            assign_btn = tk.Button(action_frame, text="Assign to Volunteer", command=self.assign_to_volunteer,
                                 font=('Arial', 10, 'bold'), bg='#f39c12', fg='white',
                                 relief='flat', bd=0, padx=15, pady=5)
            assign_btn.pack(side='left', padx=(0, 10))
        
        # Requests list
        list_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        list_frame.pack(expand=True, fill='both')
        
        # Treeview for requests
        columns = ('ID', 'User', 'Type', 'Priority', 'Status', 'Location', 'Created')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        # Configure columns
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, anchor='center')
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(list_frame, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack treeview and scrollbars
        self.tree.pack(side='left', fill='both', expand=True)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar.pack(side='bottom', fill='x')
        
        # Bind double-click event
        self.tree.bind('<Double-1>', self.view_request_details)
        
        # Load initial data
        self.load_requests()
    
    def load_requests(self):
        """Load requests from database based on user role"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Get requests from database based on user role
        user_role = self.current_user.get('role')
        status_filter = self.status_var.get()
        
        if user_role == 'admin':
            # Admin can see all requests
            if status_filter != "All":
                requests = self.db.get_emergency_requests(status_filter)
            else:
                requests = self.db.get_emergency_requests()
        elif user_role == 'user':
            # User can only see their own requests
            user_id = self.current_user.get('id')
            if status_filter != "All":
                requests = self.db.get_user_emergency_requests(user_id, status_filter)
            else:
                requests = self.db.get_user_emergency_requests(user_id)
        elif user_role == 'volunteer':
            # Volunteers can see available requests (approved/in_progress)
            if status_filter != "All":
                requests = self.db.get_available_emergency_requests(status_filter)
            else:
                requests = self.db.get_available_emergency_requests()
        else:
            requests = []
        
        # Add requests to treeview
        for req in requests:
            self.tree.insert('', 'end', values=(
                req['id'],
                req['username'],
                req['request_type'],
                req['priority'],
                req['status'],
                req['location'],
                req['created_at'][:10]  # Show only date
            ))
    
    def filter_requests(self):
        """Filter requests by status"""
        self.load_requests()
    
    def view_request_details(self, event):
        """View detailed information about a request"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        request_id = item['values'][0]
        
        # Get full request details
        requests = self.db.get_emergency_requests()
        request = next((req for req in requests if req['id'] == request_id), None)
        
        if request:
            self.show_request_details(request)
    
    def show_request_details(self, request):
        """Show detailed request information"""
        details_window = tk.Toplevel(self.window)
        details_window.title(f"Request Details - #{request['id']}")
        details_window.geometry("600x500")
        details_window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(details_window, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Request #{request['id']} Details", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(details_window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Details frame
        details_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        details_frame.pack(expand=True, fill='both')
        
        # Request information
        info_frame = tk.Frame(details_frame, bg='white')
        info_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Create labels for request details
        details = [
            ("Request ID:", str(request['id'])),
            ("User:", request['username']),
            ("Type:", request['request_type']),
            ("Description:", request['description']),
            ("Priority:", request['priority']),
            ("Status:", request['status']),
            ("Location:", request['location']),
            ("Contact Info:", request['contact_info']),
            ("Created:", request['created_at'])
        ]
        
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(info_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Action buttons for admin
        if self.current_user.get('role') == 'admin':
            action_frame = tk.Frame(details_frame, bg='white')
            action_frame.pack(fill='x', padx=30, pady=20)
            
            if request['status'] == 'pending':
                approve_btn = tk.Button(action_frame, text="Approve", command=lambda: self.update_request_status(request['id'], 'approved'),
                                      font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                                      relief='flat', bd=0, padx=20, pady=5)
                approve_btn.pack(side='left', padx=(0, 10))
                
                reject_btn = tk.Button(action_frame, text="Reject", command=lambda: self.update_request_status(request['id'], 'rejected'),
                                     font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                                     relief='flat', bd=0, padx=20, pady=5)
                reject_btn.pack(side='left', padx=(0, 10))
            
            close_btn = tk.Button(action_frame, text="Close", command=details_window.destroy,
                                font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                                relief='flat', bd=0, padx=20, pady=5)
            close_btn.pack(side='right')
        else:
            close_btn = tk.Button(details_frame, text="Close", command=details_window.destroy,
                                 font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                                 relief='flat', bd=0, padx=20, pady=5)
            close_btn.pack(pady=20)
    
    def approve_selected(self):
        """Approve selected requests"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select requests to approve")
            return
        
        for item in selection:
            request_id = self.tree.item(item)['values'][0]
            self.update_request_status(request_id, 'approved')
        
        messagebox.showinfo("Success", "Selected requests approved successfully")
        self.load_requests()
    
    def reject_selected(self):
        """Reject selected requests"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select requests to reject")
            return
        
        for item in selection:
            request_id = self.tree.item(item)['values'][0]
            self.update_request_status(request_id, 'rejected')
        
        messagebox.showinfo("Success", "Selected requests rejected successfully")
        self.load_requests()
    
    def update_request_status(self, request_id, status):
        """Update request status"""
        success = self.db.update_request_status(request_id, status)
        if success:
            messagebox.showinfo("Success", f"Request #{request_id} status updated to {status}")
            self.load_requests()
        else:
            messagebox.showerror("Error", "Failed to update request status")
    
    def assign_to_volunteer(self):
        """Assign selected request to a volunteer"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a request to assign")
            return
        
        if len(selection) > 1:
            messagebox.showwarning("Warning", "Please select only one request at a time")
            return
        
        item = self.tree.item(selection[0])
        request_id = item['values'][0]
        
        # Get request details
        requests = self.db.get_emergency_requests()
        request = next((req for req in requests if req['id'] == request_id), None)
        
        if not request:
            messagebox.showerror("Error", "Request not found")
            return
        
        if request['status'] not in ['pending', 'approved']:
            messagebox.showwarning("Warning", "Only pending or approved requests can be assigned")
            return
        
        # Show volunteer selection dialog
        self.show_volunteer_selection_dialog(request)
    
    def show_volunteer_selection_dialog(self, request):
        """Show dialog to select volunteer for assignment"""
        dialog = tk.Toplevel(self.window)
        dialog.title(f"Assign Request #{request['id']} to Volunteer")
        dialog.geometry("600x500")
        dialog.configure(bg='#f0f0f0')
        dialog.transient(self.window)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (600 // 2)
        y = (dialog.winfo_screenheight() // 2) - (500 // 2)
        dialog.geometry(f'600x500+{x}+{y}')
        
        # Header
        header_frame = tk.Frame(dialog, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Assign Request #{request['id']}", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Create main scrollable frame using ttk.Frame with scrollbar
        from tkinter import ttk
        
        # Create a frame for the scrollable area
        scrollable_frame = tk.Frame(dialog, bg='#f0f0f0')
        scrollable_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create canvas and scrollbar
        canvas = tk.Canvas(scrollable_frame, bg='#f0f0f0', highlightthickness=0)
        scrollbar = tk.Scrollbar(scrollable_frame, orient="vertical", command=canvas.yview)
        scrollable_content = tk.Frame(canvas, bg='#f0f0f0')
        
        # Configure scrolling
        scrollable_content.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_content, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind mousewheel to canvas
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        # Content frame
        content_frame = scrollable_content
        
        # Add padding to content
        content_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Request info
        info_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        info_frame.pack(fill='x', pady=(0, 15))
        
        tk.Label(info_frame, text="Request Details:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', padx=15, pady=(15, 5))
        
        details_text = f"Type: {request['request_type']}\nDescription: {request['description']}\nPriority: {request['priority']}\nLocation: {request['location']}"
        tk.Label(info_frame, text=details_text, font=('Arial', 10), 
                fg='#7f8c8d', bg='white', justify='left').pack(anchor='w', padx=15, pady=(0, 15))
        
        # Volunteer selection
        volunteer_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        volunteer_frame.pack(expand=True, fill='both')
        
        tk.Label(volunteer_frame, text="Select Volunteer:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w', padx=15, pady=(15, 5))
        
        # Get volunteers
        volunteers = self.db.get_volunteers()
        if not volunteers:
            tk.Label(volunteer_frame, text="No volunteers available", font=('Arial', 10), 
                    fg='#e74c3c', bg='white').pack(padx=15, pady=10)
            return
        
        # Volunteer listbox
        listbox_frame = tk.Frame(volunteer_frame, bg='white')
        listbox_frame.pack(fill='both', expand=True, padx=15, pady=10)
        
        scrollbar = tk.Scrollbar(listbox_frame)
        scrollbar.pack(side='right', fill='y')
        
        volunteer_listbox = tk.Listbox(listbox_frame, yscrollcommand=scrollbar.set, font=('Arial', 10))
        scrollbar.config(command=volunteer_listbox.yview)
        
        for volunteer in volunteers:
            volunteer_listbox.insert(tk.END, f"{volunteer['username']} - {volunteer['skills']} ({volunteer['location']})")
        
        volunteer_listbox.pack(side='left', fill='both', expand=True)
        
        # Admin notes
        notes_frame = tk.Frame(volunteer_frame, bg='white')
        notes_frame.pack(fill='x', padx=15, pady=(0, 15))
        
        tk.Label(notes_frame, text="Admin Notes (Optional):", font=('Arial', 10, 'bold'), 
                fg='#2c3e50', bg='white').pack(anchor='w')
        
        notes_text = tk.Text(notes_frame, height=3, font=('Arial', 10), wrap='word')
        notes_text.pack(fill='x', pady=(5, 0))
        
        # Add extra spacing before buttons
        spacer_frame = tk.Frame(content_frame, bg='#f0f0f0', height=20)
        spacer_frame.pack(fill='x')
        
        # Buttons - Make them very prominent
        button_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        button_frame.pack(fill='x', pady=(20, 20))
        
        def assign_request():
            selection = volunteer_listbox.curselection()
            if not selection:
                messagebox.showwarning("Warning", "Please select a volunteer")
                return
            
            volunteer = volunteers[selection[0]]
            admin_notes = notes_text.get('1.0', tk.END).strip()
            
            # Confirm assignment
            confirm_msg = f"Are you sure you want to assign Request #{request['id']} to {volunteer['username']}?"
            if messagebox.askyesno("Confirm Assignment", confirm_msg):
                success = self.db.assign_request_to_volunteer(request['id'], volunteer['id'], admin_notes)
                if success:
                    messagebox.showinfo("Success", f"Request #{request['id']} assigned to {volunteer['username']}")
                    dialog.destroy()
                    self.load_requests()
                else:
                    messagebox.showerror("Error", "Failed to assign request to volunteer")
        
        # Button title
        tk.Label(button_frame, text="Action Required:", font=('Arial', 14, 'bold'), 
                fg='#2c3e50', bg='white').pack(pady=(15, 10))
        
        # Center the buttons
        center_frame = tk.Frame(button_frame, bg='white')
        center_frame.pack(expand=True, pady=(0, 20))
        
        # Button layout with very prominent styling
        assign_btn = tk.Button(center_frame, text="✓ OK - ASSIGN REQUEST", command=assign_request,
                              font=('Arial', 14, 'bold'), bg='#27ae60', fg='white',
                              relief='raised', bd=3, padx=40, pady=15, width=18)
        assign_btn.pack(side='left', padx=(0, 30))
        
        cancel_btn = tk.Button(center_frame, text="✗ CANCEL", command=dialog.destroy,
                             font=('Arial', 14, 'bold'), bg='#e74c3c', fg='white',
                             relief='raised', bd=3, padx=40, pady=15, width=18)
        cancel_btn.pack(side='left')
        
        # Update scroll region after all content is added
        dialog.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))

