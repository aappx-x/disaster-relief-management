#!/usr/bin/env python3
"""
Volunteer management GUI for the Disaster Relief Management System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from disaster_relief.core.database import DatabaseManager

class VolunteerManagementGUI:
    def __init__(self, parent, current_user):
        self.parent = parent
        self.current_user = current_user
        self.db = DatabaseManager()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the volunteer management interface"""
        self.window = tk.Toplevel(self.parent)
        self.window.title("Volunteer Management")
        self.window.geometry("1200x700")
        self.window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="Volunteer Management", 
                              font=('Arial', 16, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content frame
        content_frame = tk.Frame(self.window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Controls frame
        controls_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        controls_frame.pack(fill='x', pady=(0, 10))
        
        # Filter controls
        filter_frame = tk.Frame(controls_frame, bg='white')
        filter_frame.pack(fill='x', padx=20, pady=15)
        
        tk.Label(filter_frame, text="Filter by Status:", font=('Arial', 12, 'bold'), 
                fg='#2c3e50', bg='white').pack(side='left', padx=(0, 10))
        
        self.status_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(filter_frame, textvariable=self.status_var, 
                                   font=('Arial', 12), width=15)
        status_combo['values'] = ('All', 'active', 'inactive', 'busy')
        status_combo.pack(side='left', padx=(0, 20))
        
        filter_btn = tk.Button(filter_frame, text="Filter", command=self.filter_volunteers,
                              font=('Arial', 10, 'bold'), bg='#3498db', fg='white',
                              relief='flat', bd=0, padx=15, pady=5)
        filter_btn.pack(side='left', padx=(0, 10))
        
        refresh_btn = tk.Button(filter_frame, text="Refresh", command=self.load_volunteers,
                               font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                               relief='flat', bd=0, padx=15, pady=5)
        refresh_btn.pack(side='left', padx=(0, 10))
        
        # Volunteers list
        list_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        list_frame.pack(expand=True, fill='both')
        
        # Treeview for volunteers
        columns = ('ID', 'Username', 'Email', 'Skills', 'Availability', 'Location', 'Status')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        # Configure columns
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150, anchor='center')
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(list_frame, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack treeview and scrollbars
        self.tree.pack(side='left', fill='both', expand=True)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar.pack(side='bottom', fill='x')
        
        # Bind double-click event
        self.tree.bind('<Double-1>', self.view_volunteer_details)
        
        # Load initial data
        self.load_volunteers()
    
    def load_volunteers(self):
        """Load volunteers from database"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Get volunteers from database
        volunteers = self.db.get_volunteers()
        
        # Filter by status if not "All"
        status_filter = self.status_var.get()
        if status_filter != "All":
            volunteers = [vol for vol in volunteers if vol['status'] == status_filter]
        
        # Add volunteers to treeview
        for vol in volunteers:
            self.tree.insert('', 'end', values=(
                vol['id'],
                vol['username'],
                vol['email'],
                vol['skills'][:30] + '...' if len(vol['skills']) > 30 else vol['skills'],
                vol['availability'],
                vol['location'],
                vol['status']
            ))
    
    def filter_volunteers(self):
        """Filter volunteers by status"""
        self.load_volunteers()
    
    def view_volunteer_details(self, event):
        """View detailed information about a volunteer"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        volunteer_id = item['values'][0]
        
        # Get full volunteer details
        volunteers = self.db.get_volunteers()
        volunteer = next((vol for vol in volunteers if vol['id'] == volunteer_id), None)
        
        if volunteer:
            self.show_volunteer_details(volunteer)
    
    def show_volunteer_details(self, volunteer):
        """Show detailed volunteer information"""
        details_window = tk.Toplevel(self.window)
        details_window.title(f"Volunteer Details - {volunteer['username']}")
        details_window.geometry("600x500")
        details_window.configure(bg='#f0f0f0')
        
        # Header
        header_frame = tk.Frame(details_window, bg='#2c3e50', height=50)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text=f"Volunteer Details - {volunteer['username']}", 
                              font=('Arial', 14, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # Content
        content_frame = tk.Frame(details_window, bg='#f0f0f0')
        content_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Details frame
        details_frame = tk.Frame(content_frame, bg='white', relief='raised', bd=2)
        details_frame.pack(expand=True, fill='both')
        
        # Volunteer information
        info_frame = tk.Frame(details_frame, bg='white')
        info_frame.pack(expand=True, fill='both', padx=30, pady=20)
        
        # Create labels for volunteer details
        details = [
            ("Volunteer ID:", str(volunteer['id'])),
            ("Username:", volunteer['username']),
            ("Email:", volunteer['email']),
            ("Skills:", volunteer['skills']),
            ("Availability:", volunteer['availability']),
            ("Location:", volunteer['location']),
            ("Contact Info:", volunteer['contact_info']),
            ("Status:", volunteer['status'])
        ]
        
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 12, 'bold'), 
                    fg='#2c3e50', bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=(0, 20))
            tk.Label(info_frame, text=value, font=('Arial', 12), 
                    fg='#7f8c8d', bg='white').grid(row=i, column=1, sticky='w', pady=5)
        
        # Action buttons
        action_frame = tk.Frame(details_frame, bg='white')
        action_frame.pack(fill='x', padx=30, pady=20)
        
        if self.current_user.get('role') == 'admin':
            if volunteer['status'] == 'active':
                deactivate_btn = tk.Button(action_frame, text="Deactivate", command=lambda: self.update_volunteer_status(volunteer['id'], 'inactive'),
                                          font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                                          relief='flat', bd=0, padx=20, pady=5)
                deactivate_btn.pack(side='left', padx=(0, 10))
            else:
                activate_btn = tk.Button(action_frame, text="Activate", command=lambda: self.update_volunteer_status(volunteer['id'], 'active'),
                                        font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                                        relief='flat', bd=0, padx=20, pady=5)
                activate_btn.pack(side='left', padx=(0, 10))
        
        close_btn = tk.Button(action_frame, text="Close", command=details_window.destroy,
                             font=('Arial', 10, 'bold'), bg='#95a5a6', fg='white',
                             relief='flat', bd=0, padx=20, pady=5)
        close_btn.pack(side='right')
    
    def update_volunteer_status(self, volunteer_id, new_status):
        """Update volunteer status"""
        # This would require adding a method to the database manager
        messagebox.showinfo("Info", f"Volunteer status update functionality would be implemented here")

