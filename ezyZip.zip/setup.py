#!/usr/bin/env python3
"""
Setup script for Disaster Relief Management System
"""

from setuptools import setup, find_packages
import os

# Read the README file
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Read requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="disaster-relief-management",
    version="1.0.0",
    author="Disaster Relief Team",
    author_email="admin@disaster-relief.com",
    description="A comprehensive disaster relief management system",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/disaster-relief/management-system",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.6",
    install_requires=read_requirements(),
    entry_points={
        "console_scripts": [
            "disaster-relief-gui=disaster_relief.main:main_gui",
            "disaster-relief-cli=disaster_relief.main:main_cli",
        ],
    },
    include_package_data=True,
    package_data={
        "disaster_relief": ["*.md", "*.txt"],
    },
    keywords="disaster relief, emergency management, volunteer coordination, supply management",
    project_urls={
        "Bug Reports": "https://github.com/disaster-relief/management-system/issues",
        "Source": "https://github.com/disaster-relief/management-system",
        "Documentation": "https://github.com/disaster-relief/management-system/wiki",
    },
)
