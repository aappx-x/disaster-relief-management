# Setup Instructions - Disaster Relief Management System

## 📋 Prerequisites

- **Python 3.6 or higher** (Check with `python --version`)
- **Operating System**: Windows, macOS, or Linux
- **Storage**: ~10MB free space
- **No external dependencies required!**

## 🚀 Step-by-Step Setup

### Step 1: Download/Clone the Project

1. Download or clone the project to your local machine
2. Navigate to the project directory:
   ```bash
   cd disaster-relief-management-system
   ```

### Step 2: Verify Python Installation

Check your Python version:
```bash
python --version
```
Should show Python 3.6 or higher.

### Step 3: Initialize the Database

Run the database initialization script:
```bash
python src/scripts/init_database.py
```

This will:
- Create the SQLite database file
- Set up all required tables
- Create the default admin account

### Step 4: Run the Application

Choose your preferred interface:

#### Option A: GUI Interface (Recommended)
```bash
python run_gui.py
```

#### Option B: CLI Interface
```bash
python run_cli.py
```

#### Option C: Direct Module Execution
```bash
python -m src.disaster_relief
```

## 🔐 First Login

Use the default admin credentials:
- **Email**: `admin@disaster-relief.com`
- **Password**: `admin123`

## 📁 Project Structure After Setup

```
disaster-relief-management-system/
├── src/                                # Source code
│   ├── disaster_relief/               # Main application
│   │   ├── core/                      # Database & auth
│   │   ├── gui/                       # GUI interfaces
│   │   └── cli/                       # CLI interfaces
│   └── scripts/                       # Utility scripts
├── data/                              # Database storage
│   └── disaster_relief.db            # SQLite database
├── docs/                              # Documentation
├── tests/                             # Test files
├── assets/                            # Static assets
├── requirements.txt                   # Dependencies
├── run_gui.py                        # GUI launcher
└── run_cli.py                        # CLI launcher
```

## 🧪 Verify Installation

Run the test suite to ensure everything is working:
```bash
python src/scripts/test_system.py
```

## 🎯 Next Steps

1. **Login as admin** with the default credentials
2. **Add inventory items** through the admin dashboard
3. **Register test users and volunteers**
4. **Submit emergency requests** to test the system
5. **Explore all features** to familiarize yourself

## 🔧 Configuration Options

### Custom Database Location

To use a custom database location, modify the `DatabaseManager` initialization:

```python
from src.disaster_relief.core.database import DatabaseManager

# Use custom database path
db = DatabaseManager("/path/to/your/database.db")
```

### Environment Variables

The system uses default settings, but you can customize:
- Database location
- Default admin credentials
- Application settings

## 🚨 Troubleshooting

### Common Issues and Solutions

#### 1. "Module not found" Error
**Problem**: Python can't find the modules
**Solution**: 
- Ensure you're in the project root directory
- Check that all `__init__.py` files are present
- Verify the project structure is correct

#### 2. Database Creation Failed
**Problem**: Database file not created
**Solution**:
- Check file permissions in the project directory
- Ensure the `data/` folder exists
- Run the init script with administrator privileges if needed

#### 3. GUI Not Opening
**Problem**: Tkinter GUI not displaying
**Solution**:
- Check if Tkinter is installed: `python -c "import tkinter"`
- Try the CLI version: `python run_cli.py`
- Update Python if using an old version

#### 4. Permission Errors
**Problem**: Cannot write to database or create files
**Solution**:
- Run terminal/command prompt as administrator
- Check folder permissions
- Ensure you have write access to the project directory

### Getting Help

If you encounter issues not covered here:

1. **Check the logs**: Look for error messages in the console
2. **Run tests**: Execute `python src/scripts/test_system.py`
3. **Verify setup**: Ensure all files are in the correct locations
4. **Check Python version**: Must be 3.6 or higher

## 📊 System Verification

After setup, verify these components work:

- ✅ Database initialization
- ✅ Admin login
- ✅ User registration
- ✅ Emergency request submission
- ✅ Inventory management
- ✅ Volunteer management
- ✅ Report generation

## 🔄 Updates and Maintenance

### Database Backup
```bash
cp data/disaster_relief.db backup_$(date +%Y%m%d).db
```

### Regular Maintenance
- Backup database regularly
- Monitor disk space
- Check for Python updates
- Review system logs

---

**Setup Complete!** 🎉

Your Disaster Relief Management System is now ready to use. Start with the GUI interface for the best user experience.
