#!/usr/bin/env python3
"""
GUI launcher for the Disaster Relief Management System
"""

import sys
import os

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def main():
    """Main entry point for GUI application"""
    try:
        from disaster_relief.gui.main_window import main as gui_main
        gui_main()
    except ImportError as e:
        print(f"Error importing GUI application: {e}")
        print("Make sure all required files are present.")
        sys.exit(1)
    except Exception as e:
        print(f"Error running GUI application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

