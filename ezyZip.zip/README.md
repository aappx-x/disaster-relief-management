# Disaster Relief Management System

A comprehensive Python-based disaster relief management system that allows users to submit emergency requests, volunteers to register and help, and administrators to manage the entire system including inventory and volunteer assignments.

## 🚀 Quick Start

### Prerequisites
- Python 3.6 or higher
- No external dependencies required!

### Installation & Setup

1. **Navigate to the project directory**
   ```bash
   cd disaster-relief-management-system
   ```

2. **Run the setup script**
   ```bash
   python setup.py
   ```

3. **Run the application**
   ```bash
   # GUI Interface (Recommended)
   python run_gui.py
   
   # CLI Interface
   python run_cli.py
   ```

## 🔐 Default Login Credentials

### Admin Account
- **Email**: `admin@disaster-relief.com`
- **Password**: `admin123`

## 🎯 Features

### User Features
- **Registration**: Register as a disaster victim with emergency type and location
- **Emergency Requests**: Submit requests for food, water, medical supplies, shelter, etc.
- **Request Tracking**: View the status of submitted emergency requests
- **Profile Management**: Update personal information

### Volunteer Features
- **Registration**: Register as a volunteer with skills and availability
- **Request Viewing**: View available emergency requests
- **Assignment Tracking**: View assigned tasks
- **Availability Management**: Update availability status

### Admin Features
- **Request Management**: View and manage all emergency requests
- **Inventory Management**: Add, update, and track relief supplies
- **Volunteer Management**: View and manage volunteer information
- **Assignment System**: Assign volunteers to specific requests
- **Reporting**: Generate system reports

## 📁 Project Structure

```
disaster-relief-management-system/
├── src/                                # Source code
│   ├── disaster_relief/               # Main application package
│   │   ├── core/                      # Core functionality
│   │   │   ├── database.py            # Database operations & schema
│   │   │   └── auth.py                # Authentication system
│   │   ├── gui/                       # GUI interfaces
│   │   │   ├── main_window.py         # Main GUI window
│   │   │   ├── emergency_request_form.py
│   │   │   ├── inventory_management.py
│   │   │   ├── request_management.py
│   │   │   ├── volunteer_management.py
│   │   │   └── reports.py
│   │   └── cli/                       # CLI interfaces
│   │       └── interfaces.py
│   └── scripts/                       # Utility scripts
│       ├── init_database.py           # Database initialization
│       ├── run_app.py                 # Console app launcher
│       └── test_system.py             # System tests
├── data/                              # Database storage
│   └── disaster_relief.db            # SQLite database (auto-created)
├── docs/                              # Documentation
│   ├── README.md                      # Main documentation
│   └── SETUP.md                       # Setup instructions
├── tests/                             # Test files
├── assets/                            # Static assets
├── requirements.txt                   # Dependencies
├── setup.py                          # Setup script
├── run_gui.py                        # GUI launcher
├── run_cli.py                        # CLI launcher
└── .gitignore                        # Git ignore file
```

## 🗄️ Database Schema

The system uses SQLite with the following main tables:

- **users**: Disaster victims and their information
- **volunteers**: Volunteer information and skills
- **admins**: Administrator accounts
- **emergency_requests**: Emergency requests from users
- **inventory**: Relief supplies and resources

## 🧪 Testing

Run the test suite to verify everything is working:

```bash
python src/scripts/test_system.py
```

## 📋 Usage Instructions

### 1. First Time Setup

1. **Run the setup script**:
   ```bash
   python setup.py
   ```

2. **Login as admin**:
   - Email: `admin@disaster-relief.com`
   - Password: `admin123`

3. **Add inventory items** through the admin dashboard

4. **Register users and volunteers** as needed

### 2. Daily Operations

#### For Users (Disaster Victims)
1. Register with your emergency type and location
2. Submit emergency requests for needed supplies
3. Track the status of your requests

#### For Volunteers
1. Register with your skills and availability
2. View available emergency requests
3. Accept assignments from administrators

#### For Administrators
1. Manage all emergency requests
2. Add and update inventory items
3. Assign volunteers to requests
4. Generate reports

## 🔧 Configuration

### Database Location
The SQLite database is automatically created in:
```
data/disaster_relief.db
```

### Custom Database Path
You can specify a custom database path by modifying the `DatabaseManager` initialization in the code.

## 🛠️ Development

### Adding New Features

The modular design makes it easy to extend:

1. **Database Operations**: Add new methods to `src/disaster_relief/core/database.py`
2. **User Interfaces**: Add new interfaces to `src/disaster_relief/gui/` or `src/disaster_relief/cli/`
3. **Authentication**: Extend `src/disaster_relief/core/auth.py`

### Database Backup

To backup the database:
```bash
cp data/disaster_relief.db disaster_relief_backup.db
```

## 🚨 Troubleshooting

### Common Issues

1. **"Module not found" errors**:
   - Ensure you're running from the project root directory
   - Check that all `__init__.py` files are present

2. **Database not found**:
   - Run `python setup.py` to initialize the system
   - Check file permissions in the project directory

3. **Python version errors**:
   - Ensure you're using Python 3.6 or higher
   - Check with `python --version`

### Getting Help

If you encounter issues:
1. Check that all files are in the correct locations
2. Ensure you're using Python 3.6 or higher
3. Verify file permissions for database creation
4. Run the test suite to identify issues

## 📊 System Requirements

- **Python**: 3.6 or higher
- **Operating System**: Windows, macOS, Linux
- **Storage**: ~10MB for application + database
- **Memory**: Minimal requirements
- **Dependencies**: None (uses only Python standard library)

## 🔒 Security Features

- **Password Hashing**: SHA-256 encryption
- **Input Validation**: All user inputs are validated
- **SQL Injection Prevention**: Parameterized queries
- **Role-based Access Control**: Different permissions for different user types

## 📈 Performance

- **Local Database**: No network latency
- **Direct SQL Queries**: Fast database operations
- **Minimal Resource Usage**: Lightweight application
- **Offline Operation**: Works without internet connection

## 🤝 Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

For support and questions:
- Check the troubleshooting section above
- Run the test suite to identify issues
- Review the code documentation

---

**Stay Safe!** 🛡️

This system is designed to help manage disaster relief efforts efficiently and effectively.