# Disaster Relief Management System - Setup Instructions

## 🚀 Quick Setup Guide

### Prerequisites
- Python 3.6 or higher
- No external dependencies required!

### Installation Steps

1. **Navigate to the project directory**
   ```bash
   cd disaster-relief-supply-management-frontend
   ```

2. **Install the package (optional)**
   ```bash
   pip install -e .
   ```

3. **Run the application**
   ```bash
   # GUI Interface (Recommended)
   python run_gui.py
   
   # CLI Interface
   python run_cli.py
   ```

## 🔐 Default Login Credentials

### Admin Account
- **Email**: `admin@disaster-relief.com`
- **Password**: `admin123`

## 📁 Project Structure

```
disaster-relief-supply-management-frontend/
├── src/                                # Source code
│   ├── disaster_relief/               # Main application package
│   │   ├── core/                      # Core functionality
│   │   │   ├── database.py            # Database management
│   │   │   └── auth.py                # Authentication
│   │   ├── gui/                       # GUI components
│   │   │   ├── main_window.py         # Main GUI window
│   │   │   ├── request_management.py  # Request management
│   │   │   ├── volunteer_assignments.py # Volunteer assignments
│   │   │   └── ...                    # Other GUI modules
│   │   └── cli/                       # Command-line interface
│   └── scripts/                       # Utility scripts
├── data/                              # Database files
├── run_gui.py                         # GUI application launcher
├── run_cli.py                         # CLI application launcher
├── setup.py                           # Package setup
└── requirements.txt                   # Dependencies
```

## 🎯 Features

### Admin Features
- **Request Management**: View, approve, reject, and assign requests
- **Volunteer Assignment**: Assign requests to specific volunteers
- **Inventory Management**: Track relief supplies
- **System Reports**: Generate comprehensive reports

### Volunteer Features
- **View Assignments**: See assigned tasks
- **Accept/Reject**: Respond to assignments
- **Availability Management**: Update availability status

### User Features
- **Submit Requests**: Create emergency requests
- **Track Status**: Monitor request progress
- **Profile Management**: Update personal information

## 🔧 Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   # Make sure you're in the project directory
   cd disaster-relief-supply-management-frontend
   python run_gui.py
   ```

2. **Database Issues**
   ```bash
   # Initialize database
   python src/scripts/init_database_gui.py
   ```

3. **GUI Not Opening**
   ```bash
   # Test tkinter support
   python -m tkinter
   ```

## 📞 Support

For issues or questions, please contact the development team or create an issue in the project repository.
